import React, { useState, useEffect, useRef } from 'react';
import { Input, Button, Avatar, List, Typography, Spin, Divider, Select, Modal, Tooltip, Card, message, Tag, Space } from 'antd';
import { SendOutlined, UserOutlined, RobotOutlined, SettingOutlined, ClearOutlined, PaperClipOutlined, FileTextOutlined, ExpandOutlined, OrderedListOutlined } from '@ant-design/icons';
import { useChatStore } from '../store/chatStore';
import { useAISettingsStore } from '../store/aiSettingsStore';
import { invoke } from '@tauri-apps/api/core';
import { DEFAULT_AI_PROVIDERS } from '../constants/aiProviders';
import { ClipboardReference, Message } from '../models/chat';
import { useNavigate } from 'react-router-dom';
import { ClipboardItem } from '../models/clipboard';

// 角色类型定义 (如果Role接口中没有is_default字段，则在这里重新定义)
interface RoleWithDefault {
  id: string;
  name: string; 
  description: string;
  system_prompt: string;
  is_default?: boolean;
  created_at?: number;
  updated_at?: number;
}

const { TextArea } = Input;
const { Title, Text, Paragraph } = Typography;
const { Option } = Select;

const Chat: React.FC = () => {
  const {
    sessions,
    currentSession,
    isStreaming,
    createSession,
    setCurrentSession,
    sendMessage
  } = useChatStore();
  
  const [roles, setRoles] = useState<RoleWithDefault[]>([]);
  const { settings } = useAISettingsStore();
  const defaultProviderId = settings?.selected_provider_id || 'openai';
  
  const [inputValue, setInputValue] = useState<string>('');
  const [showNewChatModal, setShowNewChatModal] = useState<boolean>(false);
  const [selectedRole, setSelectedRole] = useState<string>('default');
  const [selectedProvider, setSelectedProvider] = useState<string>(defaultProviderId);
  const [clipboardRef, setClipboardRef] = useState<ClipboardReference | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [clipboardItems, setClipboardItems] = useState<ClipboardItem[]>([]);
  const [showClipboardModal, setShowClipboardModal] = useState<boolean>(false);
  const [selectedClipboardItems, setSelectedClipboardItems] = useState<ClipboardItem[]>([]);
  const navigate = useNavigate();
  
  const [showItemDetailsModal, setShowItemDetailsModal] = useState<boolean>(false);
  const [detailItems, setDetailItems] = useState<any[]>([]);
  const [isMultipleItems, setIsMultipleItems] = useState<boolean>(false);
  
  // 加载角色列表
  useEffect(() => {
    const loadRoles = async () => {
      try {
        const loadedRoles = await invoke<RoleWithDefault[]>('get_roles');
        if (loadedRoles && loadedRoles.length > 0) {
          setRoles(loadedRoles);
          // 设置第一个角色为默认选择
          if (loadedRoles.some(r => r.is_default)) {
            const defaultRole = loadedRoles.find(r => r.is_default);
            if (defaultRole) setSelectedRole(defaultRole.id);
          } else {
            setSelectedRole(loadedRoles[0].id);
          }
        } else {
          console.warn('未加载到角色数据');
          message.warning('未能加载角色数据，将使用默认角色');
        }
      } catch (error) {
        console.error('加载角色失败:', error);
        message.error('加载角色失败，请检查网络连接');
      }
    };
    
    loadRoles();
  }, []);
  
  // 当没有会话时，自动打开新建会话模态框
  useEffect(() => {
    if (sessions.length === 0) {
      setShowNewChatModal(true);
    }
  }, [sessions.length]);
  
  // 消息区域滚动到底部
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentSession?.messages]);
  
  // 当URL中包含剪贴板引用信息时，设置引用
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const clipboardId = params.get('clipboardId');
    const clipboardContent = params.get('content');
    const roleId = params.get('roleId');
    const isMultiItems = params.get('isMultipleItems') === 'true';
    const rawItemsStr = params.get('rawItems');
    
    if (clipboardId && clipboardContent) {
      setClipboardRef({
        id: clipboardId,
        content: clipboardContent,
        timestamp: Date.now(),
        type: 'text'
      });
      
      // 处理多条内容
      if (isMultiItems && rawItemsStr) {
        try {
          const rawItems = JSON.parse(rawItemsStr);
          setDetailItems(rawItems);
          setIsMultipleItems(true);
        } catch (e) {
          console.error('解析多条内容失败', e);
        }
      }
      
      // 如果URL中包含角色ID，则选择该角色
      if (roleId) {
        setSelectedRole(roleId);
      }
      
      // 如果没有当前会话，则弹出新建会话框
      if (!currentSession) {
        setShowNewChatModal(true);
      }
    }
  }, [currentSession]);
  
  const handleSend = async () => {
    if (!inputValue.trim() && !clipboardRef) return;
    
    // 发送消息并包含剪贴板引用
    await sendMessage(inputValue, clipboardRef || undefined);
    
    // 清空输入和引用
    setInputValue('');
    setClipboardRef(null);
    
    // 清除URL参数
    if (window.history.replaceState) {
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  };
  
  const handleNewChat = async () => {
    try {
      setLoading(true);
      // 获取选中的角色
      let rolePrompt: string | undefined;
      
      try {
        const role = await invoke<RoleWithDefault>('get_role', { id: selectedRole });
        rolePrompt = role?.system_prompt;
      } catch (e) {
        console.error('获取角色失败:', e);
        message.warning('获取角色信息失败，将使用默认提示词');
      }
      
      const provider = DEFAULT_AI_PROVIDERS.find(p => p.id === selectedProvider);
      
      if (!provider) {
        console.error('未找到AI提供商', selectedProvider);
        message.error('未找到所选AI提供商');
        return;
      }
      
      createSession(
        provider,
        undefined, // 系统提示词稍后设置
        rolePrompt // 角色提示词
      );
      
      setShowNewChatModal(false);
    } catch (error) {
      console.error('创建对话失败:', error);
      message.error('创建对话失败，请重试');
    } finally {
      setLoading(false);
    }
  };
  
  const showContentDetails = (content: string) => {
    // 检测是否是多条内容
    if (isMultipleItems && detailItems.length > 0) {
      setShowItemDetailsModal(true);
    } else if (content) {
      // 单条内容时，只显示文本预览
      Modal.info({
        title: '引用内容详情',
        content: (
          <div style={{ maxHeight: '50vh', overflow: 'auto' }}>
            <Typography.Paragraph style={{ whiteSpace: 'pre-wrap' }}>
              {content}
            </Typography.Paragraph>
          </div>
        ),
        width: 600
      });
    }
  };

  const renderMessageItem = (message: Message) => (
    <List.Item className={`message-item ${message.role === 'user' ? 'user-message' : 'ai-message'}`}>
      <div className="message-content" style={{ display: 'flex', width: '100%' }}>
        <Avatar 
          icon={message.role === 'user' ? <UserOutlined /> : <RobotOutlined />}
          style={{ 
            backgroundColor: message.role === 'user' ? '#1890ff' : '#52c41a',
            marginRight: '10px'
          }}
        />
        <div style={{ flex: 1 }}>
          {/* 剪贴板引用内容 */}
          {message.clipboardRef && (
            <Card 
              size="small" 
              style={{ 
                marginBottom: '8px', 
                backgroundColor: 'rgba(0, 0, 0, 0.03)',
                borderLeft: '3px solid #1890ff',
                cursor: 'pointer'
              }}
              onClick={() => showContentDetails(message.clipboardRef?.content || '')}
              hoverable
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  {isMultipleItems ? (
                    <OrderedListOutlined style={{ marginRight: '8px', color: '#1890ff' }} />
                  ) : (
                    <FileTextOutlined style={{ marginRight: '8px' }} />
                  )}
                  <Text type="secondary" style={{ fontSize: '12px' }}>
                    {isMultipleItems 
                      ? `引用的多条内容 (${detailItems.length}条)` 
                      : '引用的剪贴板内容'}
                  </Text>
                </div>
                <Tooltip title="查看详情">
                  <ExpandOutlined style={{ color: '#1890ff' }} />
                </Tooltip>
              </div>
              <Paragraph 
                ellipsis={{ rows: 3, expandable: true, symbol: '展开' }}
                style={{ marginBottom: 0, marginTop: '4px' }}
              >
                {message.clipboardRef.content}
              </Paragraph>
            </Card>
          )}
          
          {/* 消息内容 */}
          <div style={{ 
            background: message.role === 'user' ? 'rgba(24, 144, 255, 0.1)' : 'rgba(82, 196, 26, 0.1)',
            padding: '10px',
            borderRadius: '8px',
            width: 'fit-content',
            maxWidth: '100%'
          }}>
            <Text style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
              {message.content}
            </Text>
          </div>
          
          {/* 消息时间 */}
          <div style={{ marginTop: '4px' }}>
            <Text type="secondary" style={{ fontSize: '12px' }}>
              {new Date(message.timestamp).toLocaleString('zh-CN')}
            </Text>
          </div>
        </div>
      </div>
    </List.Item>
  );
  
  // 添加获取剪贴板历史的函数
  const fetchClipboardHistory = async () => {
    try {
      const result = await invoke<ClipboardItem[]>('get_clipboard_history', { 
        limit: 20,
        offset: 0,
        filterOptions: { favorite: false, pin: false }
      });
      setClipboardItems(result || []);
    } catch (error) {
      console.error('获取剪贴板历史失败:', error);
      message.error('获取剪贴板历史失败');
    }
  };

  // 原有的函数修改为添加/删除单个选择
  const toggleClipboardItemSelection = (item: ClipboardItem) => {
    const isSelected = selectedClipboardItems.some(selected => selected.id === item.id);
    
    if (isSelected) {
      setSelectedClipboardItems(prev => prev.filter(selected => selected.id !== item.id));
    } else {
      setSelectedClipboardItems(prev => [...prev, item]);
    }
  };

  // 添加函数，确认选择并设置所有选中的剪贴板内容为引用
  const confirmSelectedClipboardItems = () => {
    if (selectedClipboardItems.length === 0) {
      message.warning('请至少选择一项内容');
      return;
    }
    
    if (selectedClipboardItems.length === 1) {
      // 单选情况，保持原有逻辑
      const item = selectedClipboardItems[0];
      setClipboardRef({
        id: item.id,
        content: item.content,
        timestamp: item.timestamp,
        type: 'text'
      });
    } else {
      // 多选情况，合并内容
      const combinedContent = selectedClipboardItems
        .map(item => item.content)
        .join('\n\n---\n\n');
      
      // 使用第一个选中项的ID作为引用ID
      setClipboardRef({
        id: selectedClipboardItems[0].id,
        content: combinedContent,
        timestamp: Date.now(),
        type: 'text'
      });
    }
    
    // 关闭模态框并清空选择
    setShowClipboardModal(false);
    setSelectedClipboardItems([]);
  };

  // 重置选择函数
  const resetClipboardSelection = () => {
    setSelectedClipboardItems([]);
  };

  // 更新打开模态框的逻辑
  const openClipboardModal = async () => {
    // 清空之前的选择
    setSelectedClipboardItems([]);
    // 获取剪贴板历史
    await fetchClipboardHistory();
    // 显示模态框
    setShowClipboardModal(true);
  };
  
  return (
    <div className="chat-container" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0 16px' }}>
        <Title level={4} style={{ margin: '16px 0' }}>
          {currentSession ? currentSession.title : 'AI 对话'}
        </Title>
        
        <div>
          <Button 
            icon={<SettingOutlined />} 
            style={{ marginRight: '8px' }}
            onClick={() => setShowNewChatModal(true)}
          >
            新建对话
          </Button>
          
          {currentSession && (
            <Button 
              icon={<ClearOutlined />} 
              onClick={() => {
                useChatStore.getState().clearSession(currentSession.id);
              }}
            >
              清空对话
            </Button>
          )}
        </div>
      </div>
      
      <Divider style={{ margin: '0 0 16px 0' }} />
      
      <div className="messages-container" style={{ flex: 1, overflow: 'auto', marginBottom: '16px', padding: '0 16px' }}>
        {currentSession && currentSession.messages.length > 0 ? (
          <List
            dataSource={currentSession.messages}
            renderItem={renderMessageItem}
          />
        ) : (
          <div style={{ textAlign: 'center', padding: '40px 0' }}>
            <Text type="secondary">
              {currentSession ? '开始与AI助手对话吧' : '请创建或选择一个对话'}
            </Text>
          </div>
        )}
        
        {isStreaming && (
          <div style={{ textAlign: 'center', padding: '10px' }}>
            <Spin size="small" />
            <Text type="secondary" style={{ marginLeft: '10px' }}>AI正在思考...</Text>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <div className="input-container" style={{ marginTop: 'auto', padding: '0 16px 16px' }}>
        {/* 引用剪贴板内容显示 */}
        {clipboardRef && (
          <Card 
            size="small" 
            style={{ 
              marginBottom: '8px', 
              backgroundColor: 'rgba(0, 0, 0, 0.03)',
              borderLeft: '3px solid #1890ff' 
            }}
            extra={
              <Button 
                type="text" 
                size="small" 
                danger 
                onClick={() => setClipboardRef(null)}
              >
                移除
              </Button>
            }
          >
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <FileTextOutlined style={{ marginRight: '8px' }} />
              <Text type="secondary" style={{ fontSize: '12px' }}>引用的剪贴板内容</Text>
            </div>
            <Paragraph 
              ellipsis={{ rows: 2, expandable: true, symbol: '展开' }}
              style={{ marginBottom: 0, marginTop: '4px' }}
            >
              {clipboardRef.content}
            </Paragraph>
          </Card>
        )}
        
        <div style={{ display: 'flex' }}>
          <Tooltip title="添加剪贴板引用">
            <Button 
              icon={<PaperClipOutlined />} 
              style={{ marginRight: '8px' }}
              disabled={!!clipboardRef}
              onClick={openClipboardModal}
            />
          </Tooltip>
          
          <TextArea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="输入消息..."
            autoSize={{ minRows: 2, maxRows: 6 }}
            onPressEnter={(e) => {
              if (!e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            style={{ flex: 1 }}
            disabled={isStreaming || !currentSession}
          />
          
          <Button 
            type="primary" 
            icon={<SendOutlined />} 
            onClick={handleSend}
            style={{ marginLeft: '8px', height: 'auto' }}
            loading={isStreaming}
            disabled={(!inputValue.trim() && !clipboardRef) || !currentSession}
          />
        </div>
        
        <Text type="secondary" style={{ fontSize: '12px', marginTop: '4px' }}>
          按下Enter发送，Shift+Enter换行
        </Text>
      </div>
      
      {/* 新建对话模态框 */}
      <Modal
        title="新建对话"
        open={showNewChatModal}
        onOk={handleNewChat}
        onCancel={() => {
          if (sessions.length > 0) {
            setShowNewChatModal(false);
          }
        }}
        okText="创建"
        cancelText="取消"
        okButtonProps={{ disabled: !selectedProvider || loading }}
        confirmLoading={loading}
      >
        <div style={{ marginBottom: '16px' }}>
          <div style={{ marginBottom: '8px' }}>选择AI提供商</div>
          <Select
            style={{ width: '100%' }}
            value={selectedProvider}
            onChange={setSelectedProvider}
            disabled={loading}
          >
            {DEFAULT_AI_PROVIDERS.map(provider => (
              <Option key={provider.id} value={provider.id}>
                {provider.name}
              </Option>
            ))}
          </Select>
        </div>
        
        <div>
          <div style={{ marginBottom: '8px' }}>选择角色</div>
          <Select
            style={{ width: '100%' }}
            value={selectedRole}
            onChange={setSelectedRole}
            disabled={loading}
            notFoundContent={<div>尚未创建角色</div>}
          >
            {roles.map(role => (
              <Option key={role.id} value={role.id}>
                {role.name}
              </Option>
            ))}
          </Select>
        </div>
      </Modal>
      
      {/* 剪贴板选择模态框 */}
      <Modal
        title="选择剪贴板引用"
        open={showClipboardModal}
        onCancel={() => {
          setShowClipboardModal(false);
          setSelectedClipboardItems([]);
        }}
        footer={null}
        styles={{ body: { paddingBottom: '60px' } }}
      >
        <div style={{ marginBottom: '16px' }}>
          <Text>点击选择剪贴板内容作为引用（可多选）</Text>
          {selectedClipboardItems.length > 0 && (
            <Button
              type="link"
              size="small"
              onClick={resetClipboardSelection}
              style={{ marginLeft: '8px' }}
            >
              清除所有选择
            </Button>
          )}
        </div>

        <List
          dataSource={clipboardItems}
          style={{ maxHeight: '400px', overflow: 'auto' }}
          renderItem={(item) => {
            const isSelected = selectedClipboardItems.some(selected => selected.id === item.id);
            return (
              <List.Item
                key={item.id}
                onClick={() => toggleClipboardItemSelection(item)}
                className="clipboard-item"
                style={{ 
                  cursor: 'pointer', 
                  padding: '8px', 
                  borderRadius: '4px', 
                  margin: '4px 0',
                  background: isSelected ? 'rgba(24, 144, 255, 0.1)' : 'transparent',
                  border: isSelected ? '1px solid #1890ff' : '1px solid transparent'
                }}
              >
                <div style={{ width: '100%' }}>
                  <div style={{ marginBottom: '4px', display: 'flex', justifyContent: 'space-between' }}>
                    <Text type="secondary" style={{ fontSize: '12px' }}>
                      {new Date(item.timestamp).toLocaleString('zh-CN')}
                    </Text>
                    {isSelected && (
                      <Tag color="blue">已选择</Tag>
                    )}
                  </div>
                  <Paragraph 
                    ellipsis={{ rows: 2, expandable: false }}
                    style={{ marginBottom: 0 }}
                  >
                    {item.content}
                  </Paragraph>
                </div>
              </List.Item>
            );
          }}
          locale={{ emptyText: '没有剪贴板历史记录' }}
        />

        <div style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          padding: '10px 24px',
          borderTop: '1px solid #f0f0f0',
          background: '#fff',
          display: 'flex',
          justifyContent: 'flex-end'
        }}>
          <Button onClick={() => {
            setShowClipboardModal(false);
            setSelectedClipboardItems([]);
          }}>取消</Button>
          <Button 
            type="primary" 
            onClick={confirmSelectedClipboardItems}
            disabled={selectedClipboardItems.length === 0}
            style={{ marginLeft: '8px' }}
          >
            确认选择 ({selectedClipboardItems.length} 项)
          </Button>
        </div>
      </Modal>
      
      {/* 添加多条内容详情模态框 */}
      <Modal
        title="引用内容详情"
        open={showItemDetailsModal}
        onCancel={() => setShowItemDetailsModal(false)}
        footer={[
          <Button key="close" onClick={() => setShowItemDetailsModal(false)}>
            关闭
          </Button>
        ]}
        width={700}
      >
        <List
          dataSource={detailItems}
          itemLayout="vertical"
          renderItem={(item, index) => (
            <List.Item
              style={{ 
                padding: '16px', 
                marginBottom: '12px', 
                border: '1px solid #e8e8e8',
                borderRadius: '8px',
                backgroundColor: index % 2 === 0 ? '#f9f9f9' : 'white',
                boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
              }}
            >
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                marginBottom: '12px',
                borderBottom: '1px solid #f0f0f0',
                paddingBottom: '8px'
              }}>
                <Typography.Text strong style={{ fontSize: '16px', color: '#1890ff' }}>
                  内容 {index + 1}
                </Typography.Text>
                <Typography.Text type="secondary" style={{ fontSize: '13px' }}>
                  {new Date(item.timestamp).toLocaleString('zh-CN')}
                </Typography.Text>
              </div>
              <Typography.Paragraph
                style={{ 
                  whiteSpace: 'pre-wrap', 
                  margin: 0, 
                  padding: '12px', 
                  backgroundColor: 'white',
                  border: '1px solid #f0f0f0',
                  borderRadius: '6px',
                  fontSize: '14px',
                  lineHeight: '1.6'
                }}
              >
                {item.content}
              </Typography.Paragraph>
            </List.Item>
          )}
        />
      </Modal>
    </div>
  );
};

export default Chat; 