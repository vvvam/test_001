import React, { useState, useEffect, useMemo } from 'react';
import { 
  Card, 
  Select, 
  Input, 
  Switch, 
  Button, 
  Form, 
  Tabs, 
  message, 
  Space, 
  Divider, 
  Tooltip, 
  InputNumber,
  Row,
  Col,
  Tag,
  Typography,
  Spin,
  Alert,
  List,
  Badge,
  Modal,
  Drawer,
  Popover
} from 'antd';
import { 
  RobotOutlined, 
  ApiOutlined, 
  KeyOutlined, 
  SettingOutlined, 
  SaveOutlined, 
  QuestionCircleOutlined, 
  CheckCircleOutlined, 
  CloseCircleOutlined,
  SyncOutlined,
  LinkOutlined,
  InfoCircleOutlined,
  EditOutlined,
  CopyOutlined,
  ThunderboltOutlined,
  CaretRightOutlined,
  ExclamationCircleOutlined
} from '@ant-design/icons';
import { useAISettingsStore } from '../store/aiSettingsStore';
import { DEFAULT_AI_PROVIDERS } from '../constants/aiProviders';
import { useTheme } from '../context/ThemeContext';
import { invoke } from '@tauri-apps/api/core';
import { AIProviderSettings } from '../models/ai';

const { Option } = Select;
const { TabPane } = Tabs;
const { Title, Text, Paragraph } = Typography;

const AISettings: React.FC = () => {
  // 获取主题上下文
  const { isDarkMode } = useTheme();

  // 获取AI设置状态
  const { 
    settings, 
    isLoading, 
    updateSettings, 
    updateProviderSettings, 
    loadModels, 
    testConnection,
    saveSettings
  } = useAISettingsStore();
  
  // 本地状态
  const [testResult, setTestResult] = useState<{
    success?: boolean;
    message?: string;
    loading: boolean;
  }>({ loading: false });
  const [loadingModels, setLoadingModels] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [configVisible, setConfigVisible] = useState(false);
  const [currentConfig, setCurrentConfig] = useState<string>('');
  const [communicationTest, setCommunicationTest] = useState<{
    success?: boolean;
    message?: string;
    loading: boolean;
  }>({ loading: false });
  
  // 当前选中的提供商ID
  const selectedProviderId = settings.selected_provider_id;
  
  // 当前提供商信息
  const selectedProvider = DEFAULT_AI_PROVIDERS.find(p => p.id === selectedProviderId);
  
  // 当前提供商设置
  const providerSettings = settings.providers[selectedProviderId] || {};
  
  // 用于跟踪用户是否更改了设置
  const [hasChanges, setHasChanges] = useState(false);
  
  // 提供商设置映射，方便访问
  const providerSettingsMap = useMemo(() => {
    return settings.providers || {};
  }, [settings.providers]);
  
  // 当前提供商设置，方便访问
  const currentProviderSettings = providerSettingsMap[selectedProviderId] || {};
  
  // 处理提供商变更
  const handleProviderChange = (value: string) => {
    updateSettings({ selected_provider_id: value });
  };
  
  // 处理API地址变更
  const handleApiUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateProviderSettings(selectedProviderId, { custom_api_base_url: e.target.value });
  };
  
  // 处理模型变更
  const handleModelChange = (value: string) => {
    // 不允许空模型值
    if (!value) {
      message.warning('必须选择一个模型');
      return;
    }
    updateProviderSettings(selectedProviderId, { selected_model: value });
  };
  
  // 处理API Key变更
  const handleApiKeyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateProviderSettings(selectedProviderId, { api_key: e.target.value });
  };
  
  // 处理模型列表URL变更
  const handleModelsUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateProviderSettings(selectedProviderId, { models_list_url: e.target.value });
  };
  
  // 加载模型列表
  const handleLoadModels = async () => {
    if (!selectedProvider) return;
    
    setLoadingModels(true);
    try {
      const models = await loadModels(selectedProviderId);
      if (models.length > 0) {
        message.success(`成功加载 ${models.length} 个模型`);
      } else {
        message.warning('未找到可用模型');
      }
    } catch (error) {
      message.error('加载模型列表失败: ' + (error instanceof Error ? error.message : String(error)));
    } finally {
      setLoadingModels(false);
    }
  };
  
  // 测试API连接
  const handleTestConnection = async () => {
    setTestResult({ loading: true });
    try {
      const result = await testConnection(selectedProviderId);
      setTestResult({
        success: result.success,
        message: result.message,
        loading: false
      });
      if (result.success) {
        message.success('连接成功');
      } else {
        message.error('连接失败: ' + result.message);
      }
    } catch (error) {
      setTestResult({
        success: false,
        message: '测试过程中出错: ' + (error instanceof Error ? error.message : String(error)),
        loading: false
      });
      message.error('测试失败: ' + (error instanceof Error ? error.message : String(error)));
    }
  };
  
  // 保存设置
  const handleSaveSettings = async () => {
    setSavingSettings(true);
    try {
      await saveSettings();
      message.success('设置已保存');
      setHasChanges(false);
    } catch (error) {
      message.error(`保存设置失败: ${error}`);
    } finally {
      setSavingSettings(false);
    }
  };
  
  // 获取可选模型列表
  const getModelOptions = () => {
    const defaultModels = selectedProvider?.defaultModels || [];
    const dynamicModels = providerSettings.dynamic_models || [];
    
    // 优先使用动态加载的模型，如果有的话
    const modelsToShow = dynamicModels.length > 0 ? dynamicModels : defaultModels;
    
    // 如果没有任何模型，添加一个默认占位符
    if (modelsToShow.length === 0) {
      return [
        <Option key="default" value="default">默认模型</Option>
      ];
    }
    
    return modelsToShow.map(model => (
      <Option key={model} value={model}>{model}</Option>
    ));
  };
  
  // 获取当前选中的模型值，确保有有效值
  const getSelectedModelValue = () => {
    // 如果有设置的模型值，则使用它
    if (providerSettings.selected_model) {
      return providerSettings.selected_model;
    }
    
    // 否则使用提供商的默认模型
    const defaultModels = selectedProvider?.defaultModels || [];
    if (defaultModels.length > 0) {
      return defaultModels[0];
    }
    
    // 最坏情况下返回 'default'
    return 'default';
  };
  
  // 渲染测试状态标签
  const renderTestStatusTag = () => {
    const { last_test_time, test_success } = providerSettings;
    
    if (!last_test_time) return null;
    
    const testTime = new Date(last_test_time).toLocaleString();
    
    return (
      <div style={{ marginTop: 8 }}>
        <Text type="secondary" style={{ marginRight: 8 }}>上次测试: {testTime}</Text>
        {test_success ? (
          <Tag color="success" icon={<CheckCircleOutlined />}>连接成功</Tag>
        ) : (
          <Tag color="error" icon={<CloseCircleOutlined />}>连接失败</Tag>
        )}
      </div>
    );
  };

  // 显示当前AI配置信息
  const showCurrentConfig = () => {
    const currentProviderSetting = settings.providers[selectedProviderId];
    const currentProvider = DEFAULT_AI_PROVIDERS.find(p => p.id === selectedProviderId);

    if (!currentProviderSetting || !currentProvider) {
      message.error('无法获取当前配置信息');
      return;
    }

    // 收集所有模型信息
    const defaultModels = currentProvider.defaultModels || [];
    const dynamicModels = currentProviderSetting.dynamic_models || [];
    const allModels = [...new Set([...defaultModels, ...dynamicModels])];

    const config = {
      provider: {
        id: currentProvider.id,
        name: currentProvider.name,
        apiBaseUrl: currentProvider.apiBaseUrl,
        supportsModelsList: currentProvider.supportsModelsList,
        requiresApiKey: currentProvider.requiresApiKey,
        description: currentProvider.description,
        website: currentProvider.website
      },
      settings: {
        custom_api_base_url: currentProviderSetting.custom_api_base_url,
        selected_model: currentProviderSetting.selected_model,
        api_key: currentProviderSetting.api_key ? '******' : undefined,
        temperature: currentProviderSetting.temperature,
        max_tokens: currentProviderSetting.max_tokens,
        use_stream: currentProviderSetting.use_stream,
        availableModels: allModels,
        dynamic_models: currentProviderSetting.dynamic_models,
        last_test_time: currentProviderSetting.last_test_time 
          ? new Date(currentProviderSetting.last_test_time).toLocaleString() 
          : undefined,
        test_success: currentProviderSetting.test_success
      }
    };

    setCurrentConfig(JSON.stringify(config, null, 2));
    setConfigVisible(true);
  };

  // 复制配置到剪贴板
  const copyConfigToClipboard = async () => {
    try {
      // 对于桌面应用，优先使用Tauri API
      if ('__TAURI__' in window) {
        await invoke('copy_to_clipboard', { content: currentConfig });
        message.success('已复制到剪贴板');
      } else {
        // 浏览器环境退回到Web API
        await navigator.clipboard.writeText(currentConfig);
        message.success('已复制到剪贴板');
      }
    } catch (error) {
      console.error('复制失败', error);
      message.error('复制失败: ' + (error instanceof Error ? error.message : String(error)));
      
      // 尝试使用备用方法
      try {
        const textarea = document.createElement('textarea');
        textarea.value = currentConfig;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        message.success('已使用备用方法复制到剪贴板');
      } catch (fallbackError) {
        message.error('所有复制方法都失败了');
      }
    }
  };
  
  // 处理最大token数变更，确保值总是有效的
  const handleMaxTokensChange = (value: number | null) => {
    // 如果值无效，使用默认值
    const tokenValue = typeof value === 'number' && !isNaN(value) ? value : 2048;
    updateProviderSettings(selectedProviderId, { max_tokens: tokenValue });
  };

  // 处理temperature变更，确保值总是有效的
  const handleTemperatureChange = (value: number | null) => {
    // 如果值无效，使用默认值
    const tempValue = typeof value === 'number' && !isNaN(value) ? value : 0.7;
    updateProviderSettings(selectedProviderId, { temperature: tempValue });
  };

  // 处理流式输出变更
  const handleStreamChange = (checked: boolean) => {
    updateProviderSettings(selectedProviderId, { use_stream: checked });
  };

  // 测试Tauri基本通信
  const testBasicTauriCommunication = async () => {
    setCommunicationTest({ loading: true });
    try {
      // 使用一个简单的命令测试Tauri通信
      if (!('__TAURI__' in window)) {
        setCommunicationTest({
          success: false,
          message: 'Tauri环境未检测到，这可能是在浏览器中运行',
          loading: false
        });
        message.error('Tauri环境未检测到');
        return;
      }

      const startTime = Date.now();
      // 调用一个简单的Tauri命令来测试通信
      const result = await invoke<string>('get_ai_settings');
      const endTime = Date.now();
      const responseTime = endTime - startTime;

      setCommunicationTest({
        success: true,
        message: `Tauri通信正常，响应时间: ${responseTime}ms`,
        loading: false
      });
      message.success('Tauri通信测试成功');
    } catch (error) {
      setCommunicationTest({
        success: false,
        message: `Tauri通信失败: ${error instanceof Error ? error.message : String(error)}`,
        loading: false
      });
      message.error('Tauri通信测试失败: ' + (error instanceof Error ? error.message : String(error)));
    }
  };

  // 渲染通信测试状态标签
  const renderCommunicationTestStatusTag = () => {
    if (communicationTest.loading) {
      return <Tag icon={<SyncOutlined spin />} color="processing">测试中...</Tag>;
    }
    
    if (communicationTest.success === undefined) {
      return <Tag icon={<QuestionCircleOutlined />} color="default">未测试</Tag>;
    }
    
    return communicationTest.success 
      ? <Tag icon={<CheckCircleOutlined />} color="success">通信正常</Tag>
      : <Tag icon={<CloseCircleOutlined />} color="error">通信失败</Tag>;
  };

  // 渲染提供商卡片底部的操作按钮
  const renderCardActions = () => {
    return [
      <Button
        key="save"
        type="primary"
        loading={savingSettings}
        onClick={handleSaveSettings}
        icon={<SaveOutlined />}
      >
        保存设置
      </Button>,
      
      <Button 
        key="test" 
        onClick={handleTestConnection}
        icon={<SyncOutlined spin={testResult.loading} />}
        loading={testResult.loading}
        disabled={!selectedProvider?.apiBaseUrl && !providerSettings.custom_api_base_url}
      >
        测试API连接
      </Button>
    ];
  };

  // 在需要的位置添加测试通信按钮和状态显示，例如在调试部分
  const renderDebugSection = () => {
    return (
      <Card 
        title={<><SettingOutlined /> 调试选项</>}
        bordered={false}
        className="settings-card"
        style={{ marginTop: '16px' }}
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <Divider orientation="left">配置管理</Divider>
          <Row gutter={16}>
            <Col span={12}>
              <Button 
                icon={<InfoCircleOutlined />}
                onClick={showCurrentConfig}
                style={{ marginRight: '8px' }}
              >
                查看当前配置
              </Button>
            </Col>
          </Row>

          <Divider orientation="left">Tauri通信测试</Divider>
          <Row gutter={16}>
            <Col span={24}>
              <Space>
                <Button 
                  type="primary"
                  icon={<ThunderboltOutlined />}
                  onClick={testBasicTauriCommunication}
                  loading={communicationTest.loading}
                >
                  测试Tauri通信
                </Button>
                {renderCommunicationTestStatusTag()}
              </Space>
              {communicationTest.message && (
                <Alert 
                  message={communicationTest.message} 
                  type={communicationTest.success ? "success" : "error"}
                  style={{ marginTop: '8px' }}
                  showIcon
                />
              )}
            </Col>
          </Row>
        </Space>
      </Card>
    );
  };

  return (
    <div className="ai-settings-page" style={{ padding: '24px' }}>
      <Card 
        title={
          <Space>
            <RobotOutlined style={{ fontSize: '20px', color: isDarkMode ? '#1890ff' : '#1677ff' }} />
            <span>AI服务设置</span>
          </Space>
        } 
        bordered={false}
        className="glass-container"
        style={{ 
          borderRadius: '12px',
          overflow: 'hidden',
          boxShadow: isDarkMode 
            ? '0 8px 24px rgba(0, 0, 0, 0.2)' 
            : '0 8px 24px rgba(0, 0, 0, 0.08)',
          background: isDarkMode 
            ? `linear-gradient(135deg, rgba(24, 24, 28, 0.95), rgba(36, 36, 42, 0.98))` 
            : `linear-gradient(135deg, rgba(255, 255, 255, 0.98), rgba(250, 250, 252, 0.95))`,
        }}
        extra={
          <Space>
            <Button 
              icon={<CopyOutlined />}
              onClick={showCurrentConfig}
              type="default"
              className={isDarkMode ? 'dark-button' : ''}
            >
              查看配置
            </Button>
            {renderCardActions()}
          </Space>
        }
      >
        <Spin spinning={isLoading} tip="加载中...">
          <Tabs 
            defaultActiveKey="basic"
            type="card"
            className={isDarkMode ? 'dark-tabs' : ''}
            items={[
              {
                key: 'basic',
                label: '基本设置',
                children: (
                  <Form layout="vertical" className={isDarkMode ? 'dark-form' : ''}>
                    <Row gutter={24}>
                      <Col xs={24} md={12}>
                        <Form.Item 
                          label={
                            <Space>
                              <span>AI服务提供商</span>
                              <Tooltip title="选择AI服务提供商">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <Select 
                            value={selectedProviderId} 
                            onChange={handleProviderChange}
                            style={{ width: '100%' }}
                            optionLabelProp="label"
                            dropdownStyle={{ maxHeight: 400 }}
                            showSearch
                            optionFilterProp="children"
                            className={isDarkMode ? 'dark-select' : ''}
                          >
                            {DEFAULT_AI_PROVIDERS.map(provider => (
                              <Option 
                                key={provider.id} 
                                value={provider.id} 
                                label={provider.name}
                              >
                                <Space>
                                  <RobotOutlined style={{ color: isDarkMode ? '#1890ff' : '#1677ff' }} />
                                  <span>{provider.name}</span>
                                  {provider.website && (
                                    <a 
                                      href={provider.website} 
                                      target="_blank" 
                                      rel="noreferrer"
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      <LinkOutlined />
                                    </a>
                                  )}
                                </Space>
                              </Option>
                            ))}
                          </Select>
                        </Form.Item>
                        
                        {selectedProvider?.description && (
                          <Alert
                            message={selectedProvider.description}
                            type="info"
                            showIcon
                            icon={<InfoCircleOutlined />}
                            style={{ 
                              marginBottom: 16,
                              background: isDarkMode ? 'rgba(24, 144, 255, 0.1)' : 'rgba(230, 244, 255, 0.8)',
                              border: isDarkMode ? '1px solid rgba(24, 144, 255, 0.3)' : '1px solid #d9e8ff'
                            }}
                          />
                        )}
                        
                        <Form.Item 
                          label={
                            <Space>
                              <span>API地址</span>
                              <Tooltip title="API服务的基础URL，通常以/v1结尾">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <Input
                            prefix={<ApiOutlined />}
                            value={providerSettings.custom_api_base_url || selectedProvider?.apiBaseUrl}
                            onChange={handleApiUrlChange}
                            placeholder="输入API基础地址"
                            className={isDarkMode ? 'dark-input' : ''}
                          />
                        </Form.Item>
                        
                        <Form.Item 
                          label={
                            <Space>
                              <span>API Key</span>
                              <Tooltip title="API服务所需的密钥">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <Input.Password
                            prefix={<KeyOutlined />}
                            value={providerSettings.api_key}
                            onChange={handleApiKeyChange}
                            placeholder={selectedProvider?.requiresApiKey ? "输入API Key" : "此提供商不需要API Key"}
                            disabled={!selectedProvider?.requiresApiKey}
                            className={isDarkMode ? 'dark-input' : ''}
                          />
                        </Form.Item>
                      </Col>
                      
                      <Col xs={24} md={12}>
                        <Form.Item 
                          label={
                            <Space>
                              <span>选择模型</span>
                              <Tooltip title="当前服务提供商支持的模型">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <Select
                            value={getSelectedModelValue()}
                            onChange={handleModelChange}
                            style={{ width: '100%' }}
                            showSearch
                            placeholder="选择模型"
                            optionFilterProp="children"
                            className={isDarkMode ? 'dark-select' : ''}
                            dropdownStyle={{ maxHeight: 400 }}
                          >
                            {getModelOptions()}
                          </Select>
                        </Form.Item>
                        
                        {selectedProvider?.supportsModelsList && (
                          <>
                            <Form.Item 
                              label={
                                <Space>
                                  <span>模型列表API地址</span>
                                  <Tooltip title="用于获取可用模型列表的API地址">
                                    <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                                  </Tooltip>
                                </Space>
                              }
                            >
                              <Input
                                value={providerSettings.models_list_url || selectedProvider?.modelsListUrl}
                                onChange={handleModelsUrlChange}
                                placeholder="输入模型列表API地址"
                                className={isDarkMode ? 'dark-input' : ''}
                                addonAfter={
                                  <Button 
                                    type="link" 
                                    size="small" 
                                    onClick={handleLoadModels}
                                    loading={loadingModels}
                                    icon={<ThunderboltOutlined />}
                                  >
                                    加载模型
                                  </Button>
                                }
                              />
                            </Form.Item>
                            
                            {providerSettings.dynamic_models && providerSettings.dynamic_models.length > 0 && (
                              <Alert
                                message={`已加载 ${providerSettings.dynamic_models.length} 个模型`}
                                type="success"
                                showIcon
                                style={{ 
                                  marginBottom: 16,
                                  background: isDarkMode ? 'rgba(82, 196, 26, 0.1)' : 'rgba(246, 255, 237, 0.8)',
                                  border: isDarkMode ? '1px solid rgba(82, 196, 26, 0.3)' : '1px solid #b7eb8f'
                                }}
                              />
                            )}
                          </>
                        )}
                        
                        {renderTestStatusTag()}
                        
                        {testResult.success !== undefined && (
                          <Alert
                            message={testResult.success ? "连接成功" : "连接失败"}
                            description={testResult.message}
                            type={testResult.success ? "success" : "error"}
                            showIcon
                            style={{ 
                              marginTop: 16,
                              background: testResult.success
                                ? (isDarkMode ? 'rgba(82, 196, 26, 0.1)' : 'rgba(246, 255, 237, 0.8)')
                                : (isDarkMode ? 'rgba(255, 77, 79, 0.1)' : 'rgba(255, 241, 240, 0.8)'),
                              border: testResult.success
                                ? (isDarkMode ? '1px solid rgba(82, 196, 26, 0.3)' : '1px solid #b7eb8f')
                                : (isDarkMode ? '1px solid rgba(255, 77, 79, 0.3)' : '1px solid #ffccc7')
                            }}
                          />
                        )}
                      </Col>
                    </Row>
                  </Form>
                )
              },
              {
                key: 'advanced',
                label: '高级设置',
                children: (
                  <Form layout="vertical" className={isDarkMode ? 'dark-form' : ''}>
                    <Row gutter={24}>
                      <Col xs={24} md={8}>
                        <Form.Item 
                          label={
                            <Space>
                              <span>Temperature (随机性)</span>
                              <Tooltip title="值越高，生成内容越随机，值越低，生成内容越确定">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <InputNumber
                            min={0}
                            max={2}
                            step={0.1}
                            value={providerSettings.temperature}
                            onChange={handleTemperatureChange}
                            style={{ width: '100%' }}
                            className={isDarkMode ? 'dark-input-number' : ''}
                          />
                        </Form.Item>
                      </Col>
                      
                      <Col xs={24} md={8}>
                        <Form.Item 
                          label={
                            <Space>
                              <span>最大Token数</span>
                              <Tooltip title="生成内容的最大token数">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <InputNumber
                            min={100}
                            max={16000}
                            step={100}
                            value={providerSettings.max_tokens}
                            onChange={handleMaxTokensChange}
                            style={{ width: '100%' }}
                            className={isDarkMode ? 'dark-input-number' : ''}
                          />
                        </Form.Item>
                      </Col>
                      
                      <Col xs={24} md={8}>
                        <Form.Item 
                          label={
                            <Space>
                              <span>使用流式输出</span>
                              <Tooltip title="启用后，会使用流式API，实现打字机效果">
                                <QuestionCircleOutlined style={{ color: isDarkMode ? 'rgba(255, 255, 255, 0.45)' : 'rgba(0, 0, 0, 0.45)' }} />
                              </Tooltip>
                            </Space>
                          }
                        >
                          <Switch
                            checked={providerSettings.use_stream}
                            onChange={handleStreamChange}
                            className={isDarkMode ? 'dark-switch' : ''}
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    
                    <Divider orientation="left">提供商设置</Divider>
                    
                    <List
                      className={isDarkMode ? 'dark-list' : ''}
                      grid={{ gutter: 16, xs: 1, sm: 1, md: 2, lg: 3, xl: 3, xxl: 3 }}
                      dataSource={DEFAULT_AI_PROVIDERS}
                      renderItem={provider => {
                        const providerConfig = settings.providers[provider.id];
                        const isConfigured = providerConfig && providerConfig.api_key;
                        const isSelected = selectedProviderId === provider.id;
                        
                        return (
                          <List.Item>
                            <Card
                              hoverable
                              className={`provider-card ${isDarkMode ? 'dark-card' : ''} ${isSelected ? 'selected-card' : ''}`}
                              size="small"
                              style={{
                                borderRadius: '8px',
                                borderColor: isSelected 
                                  ? (isDarkMode ? '#1890ff' : '#1677ff') 
                                  : (isDarkMode ? '#303030' : '#f0f0f0'),
                                background: isSelected
                                  ? (isDarkMode ? 'rgba(24, 144, 255, 0.1)' : 'rgba(24, 144, 255, 0.05)')
                                  : (isDarkMode ? 'rgba(42, 42, 46, 0.8)' : 'white')
                              }}
                              title={
                                <Space>
                                  <Badge 
                                    status={isConfigured ? 'success' : 'default'} 
                                    dot={true}
                                  />
                                  <span>{provider.name}</span>
                                  {isConfigured && (
                                    <Tag color="success" style={{ marginLeft: 4 }}>已配置</Tag>
                                  )}
                                </Space>
                              }
                              actions={[
                                <Button 
                                  key="edit" 
                                  type={isSelected ? 'primary' : 'default'}
                                  size="small"
                                  icon={<EditOutlined />}
                                  onClick={() => handleProviderChange(provider.id)}
                                >
                                  编辑
                                </Button>
                              ]}
                            >
                              <div style={{ height: '40px', overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
                                {provider.description || '没有描述'}
                              </div>
                            </Card>
                          </List.Item>
                        );
                      }}
                    />
                  </Form>
                )
              }
            ]}
          />
        </Spin>
      </Card>

      {renderDebugSection()}

      <Drawer
        title="当前AI配置信息"
        placement="right"
        onClose={() => setConfigVisible(false)}
        open={configVisible}
        width={480}
        extra={
          <Button type="primary" icon={<CopyOutlined />} onClick={copyConfigToClipboard}>
            复制
          </Button>
        }
      >
        <div style={{ background: isDarkMode ? '#1e1e1e' : '#f5f5f5', padding: '16px', borderRadius: '4px', overflow: 'auto' }}>
          <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
            <code>{currentConfig}</code>
          </pre>
        </div>
      </Drawer>

      <style>{`
        .dark-button {
          background: rgba(255, 255, 255, 0.04);
          border-color: rgba(255, 255, 255, 0.15);
          color: rgba(255, 255, 255, 0.85);
        }
        .dark-button:hover {
          background: rgba(255, 255, 255, 0.08);
          border-color: rgba(255, 255, 255, 0.2);
          color: rgba(255, 255, 255, 0.95);
        }
        .dark-input {
          background-color: rgba(0, 0, 0, 0.25);
          border-color: rgba(255, 255, 255, 0.15);
          color: rgba(255, 255, 255, 0.85);
        }
        .dark-input-number {
          background-color: rgba(0, 0, 0, 0.25);
          border-color: rgba(255, 255, 255, 0.15);
          color: rgba(255, 255, 255, 0.85);
        }
        .dark-select .ant-select-selector {
          background-color: rgba(0, 0, 0, 0.25) !important;
          border-color: rgba(255, 255, 255, 0.15) !important;
          color: rgba(255, 255, 255, 0.85) !important;
        }
        .dark-switch {
          background-color: rgba(0, 0, 0, 0.25);
        }
        .dark-form label {
          color: rgba(255, 255, 255, 0.85);
        }
        .dark-tabs .ant-tabs-nav {
          margin-bottom: 24px;
        }
        .dark-tabs .ant-tabs-tab {
          background: rgba(0, 0, 0, 0.2);
          border-color: rgba(255, 255, 255, 0.1);
        }
        .dark-tabs .ant-tabs-tab-active {
          background: rgba(24, 144, 255, 0.1);
          border-color: #1890ff;
        }
        .dark-list .ant-list-item {
          border-color: rgba(255, 255, 255, 0.1);
        }
        .provider-card {
          transition: all 0.3s;
        }
        .selected-card {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(24, 144, 255, 0.15);
        }
      `}</style>
    </div>
  );
};

export default AISettings; 