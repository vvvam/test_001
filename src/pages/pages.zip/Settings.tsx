import React, { useState, useEffect } from 'react';
import { 
  Typography, 
  Divider, 
  Form, 
  Switch, 
  Select, 
  Input,
  InputNumber, 
  Button, 
  Card, 
  Space,
  Radio,
  Tooltip,
  message
} from 'antd';
import { SaveOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { useTheme } from '../context/ThemeContext';

const { Title, Text } = Typography;
const { Option } = Select;

const Settings: React.FC = () => {
  const [form] = Form.useForm();
  const [messageApi, contextHolder] = message.useMessage();
  const { theme, setTheme } = useTheme();
  const [selectedTheme, setSelectedTheme] = useState(theme);

  useEffect(() => {
    // 设置初始表单值
    form.setFieldsValue({
      theme,
      language: 'zh_CN',
      notifications: true,
      startWithSystem: true,
      maxHistoryItems: 100,
      aiModel: 'gpt-3.5-turbo'
    });
    setSelectedTheme(theme);
  }, [form, theme]);

  const onFinish = (values: any) => {
    console.log('保存设置:', values);
    
    // 主题已在选择时立即应用，这里只处理其他设置
    
    // 实际应用中，这里会调用后端API保存设置
    messageApi.success('设置已保存');
  };

  // 处理主题选择 - 立即应用
  const handleThemeChange = (e: any) => {
    const value = e.target.value;
    setSelectedTheme(value);
    form.setFieldsValue({ theme: value });
    
    // 立即应用主题变更
    setTheme(value);
    messageApi.success(`已切换到${value === 'light' ? '亮色' : value === 'dark' ? '暗色' : '跟随系统'}主题`);
  };

  return (
    <div className="settings-container">
      {contextHolder}
      {/* 移除科技感网格背景 */}
      
      <Title level={4} style={{ margin: '16px 0', position: 'relative', zIndex: 1 }}>系统设置</Title>
      <Divider style={{ margin: '0 0 24px 0' }} />
      
      <Card bordered={false} className="glass-effect" style={{ position: 'relative', zIndex: 1 }}>
        <Form
          form={form}
          layout="vertical"
          onFinish={onFinish}
        >
          <div style={{ marginBottom: '24px' }}>
            <Title level={5}>基本设置</Title>
            <Divider style={{ margin: '8px 0 16px 0' }} />
            
            <Form.Item 
              name="theme" 
              label={
                <Space>
                  <span>主题</span>
                  <Tooltip title="选择应用的显示主题，支持亮色、暗色和系统模式，点击立即生效">
                    <QuestionCircleOutlined />
                  </Tooltip>
                </Space>
              }
            >
              <div className="theme-selector">
                <Radio.Group value={selectedTheme} onChange={handleThemeChange}>
                  <Radio.Button 
                    value="light" 
                    className={`theme-option ${selectedTheme === 'light' ? 'active pulse-effect' : ''}`}
                    style={{
                      background: selectedTheme === 'light' ? 'rgba(240, 245, 255, 0.9)' : undefined,
                      color: selectedTheme === 'light' ? '#1890ff' : undefined,
                      fontWeight: selectedTheme === 'light' ? 'bold' : 'normal',
                      boxShadow: selectedTheme === 'light' ? '0 0 8px rgba(24, 144, 255, 0.5)' : undefined,
                      transition: 'all 0.3s ease'
                    }}
                  >
                    亮色
                  </Radio.Button>
                  <Radio.Button 
                    value="dark" 
                    className={`theme-option ${selectedTheme === 'dark' ? 'active pulse-effect' : ''}`}
                    style={{
                      background: selectedTheme === 'dark' ? 'rgba(18, 22, 33, 0.9)' : undefined,
                      color: selectedTheme === 'dark' ? '#40a9ff' : undefined,
                      fontWeight: selectedTheme === 'dark' ? 'bold' : 'normal',
                      boxShadow: selectedTheme === 'dark' ? '0 0 8px rgba(24, 144, 255, 0.5)' : undefined,
                      transition: 'all 0.3s ease'
                    }}
                  >
                    暗色
                  </Radio.Button>
                  <Radio.Button 
                    value="system" 
                    className={`theme-option ${selectedTheme === 'system' ? 'active pulse-effect' : ''}`}
                    style={{
                      background: selectedTheme === 'system' ? 'rgba(var(--bg-color-rgb), 0.3)' : undefined,
                      color: selectedTheme === 'system' ? 'var(--primary-color)' : undefined,
                      fontWeight: selectedTheme === 'system' ? 'bold' : 'normal',
                      boxShadow: selectedTheme === 'system' ? '0 0 8px rgba(24, 144, 255, 0.5)' : undefined,
                      transition: 'all 0.3s ease'
                    }}
                  >
                    跟随系统
                  </Radio.Button>
                </Radio.Group>
              </div>
            </Form.Item>
            
            <Form.Item name="language" label="语言">
              <Select className="glass-select">
                <Option value="zh_CN">中文 (简体)</Option>
                <Option value="en_US">English</Option>
                <Option value="ja_JP">日本語</Option>
              </Select>
            </Form.Item>
            
            <Form.Item 
              name="notifications" 
              label="通知" 
              valuePropName="checked"
              tooltip="开启或关闭应用通知"
            >
              <Switch />
            </Form.Item>
            
            <Form.Item 
              name="startWithSystem" 
              label="开机启动" 
              valuePropName="checked"
              tooltip="设置应用是否随系统启动"
            >
              <Switch />
            </Form.Item>
          </div>
          
          <div style={{ marginBottom: '24px' }}>
            <Title level={5}>剪贴板设置</Title>
            <Divider style={{ margin: '8px 0 16px 0' }} />
            
            <Form.Item 
              name="maxHistoryItems" 
              label="最大历史记录数量" 
              tooltip="设置最多保存的剪贴板历史记录数量"
            >
              <InputNumber min={10} max={1000} style={{ width: '100%' }} />
            </Form.Item>
            
            <Form.Item 
              name="autoCategorize" 
              label="自动分类" 
              valuePropName="checked"
              tooltip="根据内容自动分类剪贴板项"
              initialValue={true}
            >
              <Switch />
            </Form.Item>

            <Form.Item 
              name="lazyLoading" 
              label="延迟加载" 
              valuePropName="checked"
              tooltip="开启延迟加载以提高大量历史记录时的性能"
              initialValue={true}
            >
              <Switch />
            </Form.Item>
          </div>
          
          <div style={{ marginBottom: '24px' }}>
            <Title level={5}>AI 功能</Title>
            <Divider style={{ margin: '8px 0 16px 0' }} />
            
            <Form.Item 
              name="aiModel" 
              label="AI 模型"
              tooltip="选择用于自动翻译和总结的AI模型"
            >
              <Select>
                <Option value="gpt-3.5-turbo">GPT-3.5 Turbo</Option>
                <Option value="gpt-4">GPT-4</Option>
                <Option value="claude-3">Claude 3</Option>
              </Select>
            </Form.Item>
            
            <Form.Item 
              name="apiKey" 
              label="API 密钥"
              tooltip="设置OpenAI或其他AI服务的API密钥"
            >
              <Input.Password placeholder="设置API密钥以启用AI功能" />
            </Form.Item>
          </div>
          
          <Form.Item>
            <Button 
              type="primary" 
              htmlType="submit" 
              icon={<SaveOutlined />}
            >
              保存设置
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default Settings; 