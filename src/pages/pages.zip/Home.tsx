import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Input, 
  List, 
  Empty, 
  Spin, 
  Button, 
  Tooltip, 
  Typography, 
  Tag, 
  Space, 
  Dropdown, 
  Menu,
  Row,
  Col,
  Card,
  Radio,
  message,
  Drawer,
  Segmented,
  SegmentedProps,
  Badge,
  Modal,
  Avatar,
  Checkbox,
  DatePicker,
  Divider,
  Switch,
  Select,
  Steps,
  Collapse,
  Tabs
} from 'antd';
import { 
  CopyOutlined, 
  DeleteOutlined, 
  PushpinOutlined, 
  StarOutlined,
  TranslationOutlined,
  SyncOutlined,
  TagsOutlined,
  FilterOutlined,
  AppstoreOutlined,
  BarsOutlined,
  InfoCircleOutlined,
  MoreOutlined,
  FolderOutlined,
  SettingOutlined,
  ClockCircleOutlined,
  DownOutlined,
  UpOutlined,
  EditOutlined,
  RobotOutlined,
  DeleteFilled,
  ClearOutlined,
  SearchOutlined,
  ReloadOutlined,
  StarFilled,
  PushpinFilled,
  BulbOutlined,
  SortAscendingOutlined,
  SortDescendingOutlined,
  UnorderedListOutlined,
  LoadingOutlined,
  FolderOpenOutlined,
  CheckCircleFilled
} from '@ant-design/icons';
import { invoke } from '@tauri-apps/api/core';
import { format } from 'date-fns';
import { useClipboardStore } from '../store/clipboardStore';
import { ClipboardItem, ClearOption, AIRole } from '../models/clipboard';
import { 
  PREDEFINED_CATEGORIES, 
  getCategoryColor, 
  getCategoryLabel,
  detectCategory 
} from '../constants/categories';
import { useTheme } from '../context/ThemeContext';
import useRoleStore from '../store/roleStore';
import { Role } from '../models/role';
import moment from 'moment';
import './Home.css'; // 确保导入样式文件
import dayjs from 'dayjs';
import 'dayjs/locale/zh-cn';
import locale from 'antd/es/date-picker/locale/zh_CN';

const { Search } = Input;
const { Text, Paragraph, Title } = Typography;

// 预定义的AI角色
const AI_ROLES: AIRole[] = [
  {
    id: 'translator',
    name: '翻译专家',
    description: '将内容翻译成中文或其他语言',
    systemPrompt: '你是一位专业翻译，请将用户提供的内容翻译成中文，保持原文的格式和风格。',
    icon: '🌐'
  },
  {
    id: 'summarizer',
    name: '总结助手',
    description: '为长文本生成简洁的摘要',
    systemPrompt: '你是一位总结专家，请为用户提供的内容创建一个简洁的摘要，突出关键点。',
    icon: '📝'
  },
  {
    id: 'coder',
    name: '代码专家',
    description: '分析、解释和优化代码',
    systemPrompt: '你是一位编程专家，请分析用户提供的代码，解释其功能，并给出优化建议。',
    icon: '💻'
  },
  {
    id: 'writer',
    name: '文案专家',
    description: '改进文本的表达和风格',
    systemPrompt: '你是一位文案专家，请帮助用户优化文本表达，使其更加生动、流畅和专业。',
    icon: '✍️'
  }
];

// 将Role转换为AIRole的辅助函数
const roleToAIRole = (role: Role): AIRole => {
  return {
    id: role.id,
    name: role.name,
    description: role.description,
    systemPrompt: role.system_prompt,
    icon: role.icon
  };
};

// 定义AI分析组件相关状态和接口
interface AIAnalysisState {
  selectedItems: string[];
  timeRange: 'today' | 'week' | 'month' | 'custom' | null;
  customStartDate: Date | null;
  customEndDate: Date | null;
  selectedRole: string | null;
  isAnalyzing: boolean;
  analysisResult: string | null;
  step: 'select' | 'role' | 'result';
}

// 使用普通React组件，不使用memo优化
const ClipboardCard = ({ 
  item, 
  isExpanded, 
  toggleExpand, 
  onDetails, 
  onCopy, 
  onFavorite, 
  onPin, 
  onDelete,
  onMore,
  onAnalyze,
  viewMode,
  isDarkMode
}: {
  item: ClipboardItem;
  isExpanded: boolean;
  toggleExpand: (id: string, e: React.MouseEvent) => void;
  onDetails: (item: ClipboardItem) => void;
  onCopy: (id: string) => void;
  onFavorite: (id: string) => void;
  onPin: (id: string) => void;
  onDelete: (id: string) => void;
  onMore: (item: ClipboardItem) => void;
  onAnalyze: (item: ClipboardItem) => void;
  viewMode: 'list' | 'grid';
  isDarkMode: boolean;
}) => {
  // 渲染列表视图卡片
  if (viewMode === 'list') {
    return (
      <List.Item className="clipboard-list-item">
        <div className={`list-item-container ${isDarkMode ? 'dark-theme' : ''}`} style={{
          borderLeft: `4px solid ${getCategoryColor(item.category || 'text')}`,
          borderRadius: '12px',
          overflow: 'hidden',
          boxShadow: isDarkMode 
            ? '0 4px 16px rgba(0, 0, 0, 0.15)' 
            : '0 4px 16px rgba(0, 0, 0, 0.06)',
          transition: 'all 0.3s ease',
          background: isDarkMode 
            ? `linear-gradient(135deg, rgba(18, 18, 18, 0.9), rgba(30, 30, 30, 0.95))` 
            : `linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 248, 248, 0.98))`,
        }}>
          <div className="clipboard-card-content" style={{ display: 'flex', alignItems: 'flex-start', position: 'relative' }}>
            {/* 修改序号样式，取消绝对定位，改为内联元素 */}
            <div className="clipboard-index" style={{ 
              fontWeight: 'bold',
              color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.4)',
              fontSize: '16px',
              marginRight: '8px'
            }}>
              #{item.index || '-'}
            </div>
            
            <div 
              className={`clipboard-content ${isExpanded ? '' : 'content-ellipsis'}`}
              style={{ cursor: 'pointer', flex: 1, paddingLeft: '4px' }}
              onClick={() => onDetails(item)}
              onDoubleClick={() => onDetails(item)}
            >
              {item.content}
            </div>
            {!isExpanded && item.content.length > 150 && (
              <Button 
                type="link" 
                size="small" 
                onClick={(e) => toggleExpand(item.id, e)}
                icon={<DownOutlined />}
              >
                展开
              </Button>
            )}
            {isExpanded && (
              <Button 
                type="link" 
                size="small" 
                onClick={(e) => toggleExpand(item.id, e)}
                icon={<UpOutlined />}
              >
                收起
              </Button>
            )}
            
            <div className="clipboard-footer">
              <div className="clipboard-info">
                <Space wrap>
                  {item.category && (
                    <span className="clipboard-category" style={{
                      display: 'inline-block',
                      padding: '2px 8px',
                      fontSize: '12px',
                      borderRadius: '12px',
                      background: isDarkMode 
                        ? `rgba(${getCategoryColor(item.category).replace(/[^\d,]/g, '')}, 0.15)` 
                        : `rgba(${getCategoryColor(item.category).replace(/[^\d,]/g, '')}, 0.08)`,
                      color: getCategoryColor(item.category),
                      border: `1px solid ${getCategoryColor(item.category).replace('rgb', 'rgba').replace(')', ', 0.3)')}`,
                      marginRight: '8px'
                    }}>
                      {getCategoryLabel(item.category)}
                    </span>
                  )}
                  <span className="clipboard-timestamp" style={{ 
                    fontSize: '12px', 
                    color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.45)',
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <ClockCircleOutlined style={{ marginRight: 4 }} />
                    {format(new Date(item.timestamp), 'MM-dd HH:mm')}
                  </span>
                </Space>
              </div>
              <div className="clipboard-actions">
                <Tooltip title="AI分析">
                  <Button 
                    type="primary" 
                    size="small" 
                    icon={<RobotOutlined />} 
                    onClick={(e) => {
                      e.stopPropagation();
                      onAnalyze(item);
                    }} 
                    style={{ marginRight: '5px' }}
                  >
                    AI分析
                  </Button>
                </Tooltip>
                <Tooltip title="复制到剪贴板">
                  <Button type="text" size="small" icon={<CopyOutlined />} onClick={(e) => {
                    e.stopPropagation();
                    onCopy(item.id);
                  }} />
                </Tooltip>
                <Tooltip title={item.favorite ? "取消收藏" : "收藏"}>
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<StarOutlined />} 
                    onClick={(e) => {
                      e.stopPropagation();
                      onFavorite(item.id);
                    }}
                    style={{ color: item.favorite ? '#faad14' : undefined }} 
                  />
                </Tooltip>
                <Tooltip title={item.pinned ? "取消固定" : "固定"}>
                  <Button 
                    type="text" 
                    size="small" 
                    icon={<PushpinOutlined />} 
                    onClick={(e) => {
                      e.stopPropagation();
                      onPin(item.id);
                    }}
                    style={{ color: item.pinned ? '#1890ff' : undefined }} 
                  />
                </Tooltip>
                <Dropdown 
                  menu={{ 
                    items: [
                      {
                        key: 'translate',
                        label: '翻译',
                        icon: <TranslationOutlined />,
                        onClick: () => onMore(item)
                      },
                      {
                        key: 'edit',
                        label: '编辑',
                        icon: <EditOutlined />,
                        onClick: () => onDetails(item)
                      },
                      {
                        key: 'details',
                        label: '详情',
                        icon: <InfoCircleOutlined />,
                        onClick: () => onDetails(item)
                      },
                      {
                        type: 'divider'
                      },
                      {
                        key: 'delete',
                        label: '删除',
                        icon: <DeleteOutlined />,
                        danger: true,
                        onClick: () => {
                          onDelete(item.id);
                        }
                      }
                    ]
                  }} 
                  placement="bottomRight"
                >
                  <Button type="text" size="small" icon={<MoreOutlined />} />
                </Dropdown>
              </div>
            </div>
          </div>
        </div>
      </List.Item>
    );
  }
  
  // 渲染网格视图卡片
  return (
    <Card 
      hoverable 
      style={{ 
        width: '100%', 
        height: '280px', 
        marginBottom: '20px',
        borderTop: `4px solid ${getCategoryColor(item.category || 'text')}`,
        position: 'relative',
        overflow: 'hidden',
        borderRadius: '16px',
        boxShadow: isDarkMode 
          ? '0 8px 24px rgba(0, 0, 0, 0.25)' 
          : '0 8px 24px rgba(0, 0, 0, 0.1)',
        transition: 'all 0.3s ease',
        background: isDarkMode 
          ? `linear-gradient(135deg, rgba(24, 24, 28, 0.9), rgba(36, 36, 40, 0.95))` 
          : `linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(250, 250, 250, 0.98))`,
        backdropFilter: 'blur(12px)'
      }}
      onClick={() => onDetails(item)}
    >
      <div className="clipboard-card-content">
        {/* 修改序号样式，取消绝对定位，改为内联元素 */}
        <div className="clipboard-index" style={{ 
          fontWeight: 'bold',
          color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.4)',
          fontSize: '16px',
          marginRight: '8px'
        }}>
          #{item.index || '-'}
        </div>
        
        <div 
          className={`clipboard-content ${isExpanded ? '' : 'content-ellipsis'}`}
          style={{ 
            cursor: 'pointer', 
            marginTop: '24px',
            fontSize: '15px',
            lineHeight: '1.6',
            color: isDarkMode ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.85)',
            height: '160px',
            overflow: 'auto',
            padding: '0 10px',
          }}
          onClick={() => onDetails(item)}
          onDoubleClick={() => onDetails(item)}
        >
          {item.content}
        </div>
        {!isExpanded && item.content.length > 100 && (
          <Button 
            type="link" 
            size="small" 
            onClick={(e) => toggleExpand(item.id, e)}
            icon={<DownOutlined />}
          >
            展开
          </Button>
        )}
        {isExpanded && (
          <Button 
            type="link" 
            size="small" 
            onClick={(e) => toggleExpand(item.id, e)}
            icon={<UpOutlined />}
          >
            收起
          </Button>
        )}
        
        <div className="clipboard-footer" style={{
          position: 'absolute',
          bottom: '0',
          left: '0',
          right: '0',
          padding: '16px 20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          borderTop: isDarkMode 
            ? '1px solid rgba(255, 255, 255, 0.08)' 
            : '1px solid rgba(0, 0, 0, 0.05)',
          background: isDarkMode 
            ? 'rgba(0, 0, 0, 0.25)' 
            : 'rgba(248, 248, 248, 0.8)',
          backdropFilter: 'blur(10px)'
        }}>
          <div className="clipboard-info">
            {item.category && (
              <span className="clipboard-category" style={{
                display: 'inline-block',
                padding: '2px 8px',
                fontSize: '12px',
                borderRadius: '12px',
                background: isDarkMode 
                  ? `rgba(${getCategoryColor(item.category).replace(/[^\d,]/g, '')}, 0.15)` 
                  : `rgba(${getCategoryColor(item.category).replace(/[^\d,]/g, '')}, 0.08)`,
                color: getCategoryColor(item.category),
                border: `1px solid ${getCategoryColor(item.category).replace('rgb', 'rgba').replace(')', ', 0.3)')}`,
                marginRight: '8px'
              }}>
                {getCategoryLabel(item.category)}
              </span>
            )}
            <span className="clipboard-timestamp" style={{ 
              fontSize: '12px', 
              color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.45)',
              display: 'flex',
              alignItems: 'center'
            }}>
              <ClockCircleOutlined style={{ marginRight: 4 }} />
              {format(new Date(item.timestamp), 'MM-dd HH:mm')}
            </span>
          </div>
          <div className="clipboard-actions">
            {item.favorite && <StarFilled style={{ color: '#faad14', fontSize: '16px', marginRight: '6px' }} />}
            {item.pinned && <PushpinFilled style={{ color: '#1890ff', fontSize: '16px' }} />}
          </div>
        </div>
      </div>
    </Card>
  );
};

const Home: React.FC = () => {
  const { 
    items,
    filteredItems, 
    loading, 
    searchText, 
    setSearchText,
    pinItem,
    favoriteItem,
    removeItem,
    copyToClipboard,
    fetchItems,
    translateItem,
    summarizeItem,
    categorizeItem,
    editItem, // 添加编辑方法
    setShowFavoritesOnly,
    setShowPinnedOnly,
    setSelectedCategory,
    showFavoritesOnly,
    showPinnedOnly,
    selectedCategory,
    clearAll,
    clearItems,
    setupEventListeners,
    initializeStore,
    isInitialized
  } = useClipboardStore();
  
  // 获取主题上下文
  const { isDarkMode } = useTheme();
  
  // 本地状态
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [currentItem, setCurrentItem] = useState<ClipboardItem | null>(null);
  const [showDetailsDrawer, setShowDetailsDrawer] = useState(false);
  const [localLoading, setLocalLoading] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);
  
  // 添加折叠状态管理
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({});
  
  // 添加编辑模式状态
  const [editMode, setEditMode] = useState(false);
  const [editContent, setEditContent] = useState('');
  
  // AI分析相关状态
  const [showAIAnalysisModal, setShowAIAnalysisModal] = useState(false);
  const [aiAnalysisState, setAIAnalysisState] = useState<AIAnalysisState>({
    selectedItems: [],
    timeRange: null,
    customStartDate: null,
    customEndDate: null,
    selectedRole: null,
    isAnalyzing: false,
    analysisResult: null,
    step: 'select'
  });
  
  // 添加过滤抽屉中的时间范围状态
  const [filterDateRange, setFilterDateRange] = useState<{
    type: 'today' | 'week' | 'month' | 'custom' | null;
    startDate: Date | null;
    endDate: Date | null;
  }>({
    type: null,
    startDate: null,
    endDate: null
  });
  
  // 切换折叠状态
  const toggleExpand = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  }, []);
  
  // 是否已展开
  const isExpanded = useCallback((id: string) => {
    return !!expandedItems[id];
  }, [expandedItems]);
  
  // 从角色管理中获取角色
  const { roles, loadRoles } = useRoleStore();
  
  // 当组件挂载时加载角色
  useEffect(() => {
    loadRoles();
  }, [loadRoles]);
  
  // 在组件挂载时执行一次性初始化
  useEffect(() => {
    const initialize = async () => {
      setLocalLoading(true);
      try {
        await initializeStore();
        // 初始化完成后立即获取剪贴板数据
        await fetchItems();
        
        // 提示清空功能
        const hasShownClearTip = localStorage.getItem('hasShownClearTip');
        if (!hasShownClearTip) {
          setTimeout(() => {
            message.info({
              content: (
                <div>
                  <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>剪贴板管理提示</div>
                  <div>您可以通过页面顶部的"清空剪贴板历史"按钮管理您的剪贴板记录</div>
                </div>
              ),
              duration: 6,
              icon: <InfoCircleOutlined style={{ color: '#1890ff' }} />
            });
            localStorage.setItem('hasShownClearTip', 'true');
          }, 1000);
        }
      } finally {
        // 延迟关闭加载状态，避免闪烁
        setTimeout(() => {
          setLocalLoading(false);
        }, 300);
      }
    };
    
    initialize();
  }, [initializeStore, fetchItems]);
  
  // 定期刷新剪贴板数据（作为备用机制）
  useEffect(() => {
    const refreshInterval = setInterval(() => {
      if (!loading) {
        fetchItems();
      }
    }, 30000); // 30秒刷新一次
    
    return () => clearInterval(refreshInterval);
  }, [fetchItems, loading]);
  
  // 手动刷新处理函数
  const handleManualRefresh = useCallback(async () => {
    setLocalLoading(true);
    try {
      await fetchItems();
    } finally {
      setTimeout(() => {
        setLocalLoading(false);
      }, 300);
    }
  }, [fetchItems]);
  
  // 打开详情抽屉
  const showItemDetails = useCallback((item: ClipboardItem) => {
    setCurrentItem(item);
    // 同时更新编辑内容，以便编辑模式正常工作
    setEditContent(item.content);
    setEditMode(false);
    setShowDetailsDrawer(true);
  }, []);
  
  // 处理分类选择
  const handleCategoryChange = useCallback((id: string, category: string) => {
    categorizeItem(id, category);
    message.success(`已将内容分类为 ${getCategoryLabel(category)}`);
  }, [categorizeItem]);
  
  // 处理分析单个项目
  const handleAnalyzeItem = (item: ClipboardItem) => {
    // 打开AI分析模态框，预选择当前项
    setAIAnalysisState({
      ...aiAnalysisState,
      selectedItems: [item.id],
      step: 'select'
    });
    setShowAIAnalysisModal(true);
  };
  
  // 处理清空操作
  const handleClearOption = useCallback((option: ClearOption) => {
    setShowClearModal(false);
    clearItems(option);
  }, [clearItems]);
  
  // 结合全局loading和本地loading状态
  const isLoading = loading || localLoading;

  // 按照重要性排序（固定 > 收藏），然后按照时间戳逆序排序（新的在前）
  const filtered = filteredItems.sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    if (a.favorite && !b.favorite) return -1;
    if (!a.favorite && b.favorite) return 1;
    return b.timestamp - a.timestamp; // 时间戳降序排序，确保新的内容在前
  });
  
  // 添加序号信息
  const filteredItemsWithIndex = useMemo(() => {
    return filteredItems.map((item, index) => ({
      item,
      index
    }));
  }, [filteredItems]);

  const navigate = useNavigate();

  // 处理时间范围选择
  const handleTimeRangeSelect = useCallback((range: 'today' | 'week' | 'month' | 'custom' | null) => {
    const now = new Date();
    let startDate: Date | null = null;
    let endDate: Date | null = now;
    
    switch (range) {
      case 'today':
        startDate = new Date(now);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - now.getDay()); // 本周日为起始日
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'custom':
        // 保持为null，用户自定义
        break;
      default:
        // 如果为null，则不进行时间筛选
        startDate = null;
        endDate = null;
    }
    
    setAIAnalysisState(prev => ({
      ...prev,
      timeRange: range,
      customStartDate: startDate,
      customEndDate: endDate
    }));
    
    // 根据时间范围筛选条目
    if (range !== null && range !== 'custom') {
      const filtered = items.filter(item => {
        const itemDate = new Date(item.timestamp);
        return startDate && itemDate >= startDate && itemDate <= now;
      });
      
      setAIAnalysisState(prev => ({
        ...prev,
        selectedItems: filtered.map(item => item.id)
      }));
    }
  }, [items]);
  
  // 处理单个项目选择
  const toggleItemSelection = useCallback((item: ClipboardItem) => {
    setAIAnalysisState(prev => {
      const isSelected = prev.selectedItems.some(i => i === item.id);
      
      if (isSelected) {
        return {
          ...prev,
          selectedItems: prev.selectedItems.filter(i => i !== item.id)
        };
      } else {
        return {
          ...prev,
          selectedItems: [...prev.selectedItems, item.id]
        };
      }
    });
  }, []);
  
  // 处理全选
  const selectAllItems = useCallback(() => {
    setAIAnalysisState(prev => ({
      ...prev,
      selectedItems: items.map(item => item.id)
    }));
  }, [items]);
  
  // 添加复位和关闭分析模态框函数
  const resetAIAnalysis = useCallback(() => {
    setAIAnalysisState({
      selectedItems: [],
      timeRange: null,
      customStartDate: null,
      customEndDate: null,
      selectedRole: null,
      isAnalyzing: false,
      analysisResult: null,
      step: 'select'
    });
  }, []);

  // 打开AI分析模态框
  const openAIAnalysisModal = useCallback(() => {
    resetAIAnalysis();
    setShowAIAnalysisModal(true);
  }, [resetAIAnalysis]);

  // 关闭AI分析模态框
  const closeAIAnalysisModal = useCallback(() => {
    setShowAIAnalysisModal(false);
    resetAIAnalysis();
  }, [resetAIAnalysis]);

  // 修改getDefaultRoleId函数，使用类型断言
  const getDefaultRoleId = useCallback(() => {
    // 尝试获取默认角色（使用类型断言处理is_default字段）
    const defaultRole = roles.find(role => (role as any).is_default === true);
    if (defaultRole) return defaultRole.id;
    
    // 如果没有默认角色，使用第一个角色
    if (roles.length > 0) return roles[0].id;
    
    // 如果没有角色，返回null
    return null;
  }, [roles]);
  
  // 修改AI分析流程，点击内容直接跳转
  const handleAnalyzeItems = useCallback(async () => {
    const selectedItemsData = aiAnalysisState.selectedItems
      .map(id => items.find(item => item.id === id))
      .filter((item): item is ClipboardItem => item !== undefined);
    
    if (selectedItemsData.length === 0) {
      message.error('请至少选择一条记录');
      return;
    }
    
    // 获取默认角色ID
    const defaultRoleId = getDefaultRoleId();
    if (!defaultRoleId) {
      message.error('无可用角色，请先创建角色');
      return;
    }
    
    // 构建URL参数
    const params = new URLSearchParams();
    
    // 如果只有一个选中项，直接传递内容
    if (selectedItemsData.length === 1) {
      const clipboardItem = selectedItemsData[0];
      params.append('clipboardId', clipboardItem.id);
      params.append('content', clipboardItem.content);
    } else {
      // 如果有多个选中项，合并内容并以美观的格式传递
      params.append('clipboardId', selectedItemsData[0].id);
      params.append('isMultipleItems', 'true');
      params.append('itemsCount', selectedItemsData.length.toString());
      
      // 合并内容，每条内容占一行，使用格式化的方式
      const formattedContent = selectedItemsData
        .map((item, index) => `[Item ${index + 1}]：${item.content}`)
        .join('\n\n');
      
      // 同时传递原始内容数组的JSON字符串，用于后续展示
      const rawItems = selectedItemsData.map(item => ({
        id: item.id,
        content: item.content,
        timestamp: item.timestamp
      }));
      params.append('rawItems', JSON.stringify(rawItems));
      
      params.append('content', formattedContent);
    }
    
    // 添加角色ID参数
    params.append('roleId', defaultRoleId);
    
    // 跳转到聊天页面
    window.location.href = `/chat?${params.toString()}`;
  }, [aiAnalysisState.selectedItems, items, getDefaultRoleId]);
  
  // 修改选择项目的处理方式，点击项目即可选择
  const toggleSelectItem = useCallback((itemId: string) => {
    setAIAnalysisState(prev => {
      const isSelected = prev.selectedItems.includes(itemId);
      
      if (isSelected) {
        return {
          ...prev,
          selectedItems: prev.selectedItems.filter(id => id !== itemId)
        };
      } else {
        return {
          ...prev,
          selectedItems: [...prev.selectedItems, itemId]
        };
      }
    });
  }, []);
  
  // 处理过滤器中的时间范围选择
  const handleFilterTimeRangeSelect = useCallback((range: 'today' | 'week' | 'month' | 'custom' | null) => {
    const now = new Date();
    let startDate: Date | null = null;
    let endDate: Date | null = now;
    
    switch (range) {
      case 'today':
        startDate = new Date(now);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - now.getDay()); // 本周日为起始日
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'custom':
        // 保持为null，用户自定义
        break;
      default:
        // 如果为null，则不进行时间筛选
        startDate = null;
        endDate = null;
    }
    
    setFilterDateRange({
      type: range,
      startDate,
      endDate
    });
  }, []);

  // 扩展应用筛选器函数以包含日期范围
  const applyFilters = useCallback(() => {
    if (!items || items.length === 0) return;
    
    // 基于现有筛选条件和新增的日期范围筛选
    const filtered = items.filter(item => {
      // 搜索文本
      if (searchText && !item.content.toLowerCase().includes(searchText.toLowerCase())) {
        return false;
      }
      
      // 收藏状态
      if (showFavoritesOnly && !item.favorite) {
        return false;
      }
      
      // 固定状态
      if (showPinnedOnly && !item.pinned) {
        return false;
      }
      
      // 分类
      if (selectedCategory && item.category !== selectedCategory) {
        return false;
      }
      
      // 日期范围筛选
      if (filterDateRange.type && filterDateRange.type !== 'custom' && filterDateRange.startDate) {
        const itemDate = new Date(item.timestamp);
        return itemDate >= filterDateRange.startDate && itemDate <= (filterDateRange.endDate || new Date());
      }
      
      // 自定义日期范围
      if (filterDateRange.type === 'custom' && filterDateRange.startDate && filterDateRange.endDate) {
        const itemDate = new Date(item.timestamp);
        return itemDate >= filterDateRange.startDate && itemDate <= filterDateRange.endDate;
      }
      
      return true;
    });
    
    return filtered;
  }, [items, searchText, showFavoritesOnly, showPinnedOnly, selectedCategory, filterDateRange]);

  // 更新过滤项
  useEffect(() => {
    if (items.length > 0) {
      const filteredResults = applyFilters();
      if (filteredResults) {
        useClipboardStore.setState({ filteredItems: filteredResults });
      }
    }
  }, [items, searchText, showFavoritesOnly, showPinnedOnly, selectedCategory, filterDateRange, applyFilters]);

  // 在其他state声明附近添加这行
  const [roleSearchText, setRoleSearchText] = useState('');
  
  // 添加角色筛选逻辑
  const filteredRoles = useMemo(() => {
    if (!roleSearchText.trim()) return roles;
    
    return roles.filter(role => 
      role.name.toLowerCase().includes(roleSearchText.toLowerCase()) || 
      role.description.toLowerCase().includes(roleSearchText.toLowerCase())
    );
  }, [roles, roleSearchText]);

  // 修改AI分析模态框内容
  const renderAIAnalysisModal = () => (
    <Modal
      title="选择内容进行分析"
      open={showAIAnalysisModal}
      onCancel={closeAIAnalysisModal}
      footer={[
        <Button key="cancel" onClick={closeAIAnalysisModal}>取消</Button>,
        <Button
          key="analyze"
          type="primary"
          disabled={aiAnalysisState.selectedItems.length === 0}
          onClick={handleAnalyzeItems}
        >
          开始分析 ({aiAnalysisState.selectedItems.length} 项)
        </Button>
      ]}
      width={800}
    >
      <div style={{ marginBottom: '16px' }}>
        <Text>点击选择要分析的内容</Text>
        {aiAnalysisState.selectedItems.length > 0 && (
          <Button
            type="link"
            size="small"
            onClick={() => setAIAnalysisState(prev => ({ ...prev, selectedItems: [] }))}
            style={{ marginLeft: '8px' }}
          >
            清除选择
          </Button>
        )}
        <Button
          type="link"
          size="small"
          onClick={selectAllItems}
          style={{ marginLeft: '8px' }}
        >
          全选
        </Button>
      </div>
      
      <div style={{ maxHeight: '60vh', overflowY: 'auto' }}>
        <List
          dataSource={filteredItemsWithIndex}
          renderItem={({ item, index }) => {
            const isSelected = aiAnalysisState.selectedItems.includes(item.id);
            return (
              <List.Item
                key={item.id}
                onClick={() => toggleSelectItem(item.id)}
                style={{
                  cursor: 'pointer',
                  padding: '12px',
                  marginBottom: '8px',
                  border: isSelected ? '1px solid #1890ff' : '1px solid #f0f0f0',
                  borderRadius: '8px',
                  backgroundColor: isSelected ? 'rgba(24, 144, 255, 0.1)' : 'white'
                }}
              >
                <div style={{ width: '100%' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <div>
                      <Tag color={isSelected ? 'blue' : 'default'}>
                        {isSelected ? '已选择' : `项目 ${index + 1}`}
                      </Tag>
                      <Tag color="cyan">{new Date(item.timestamp).toLocaleString('zh-CN')}</Tag>
                    </div>
                    <div>
                      {item.favorite && <Tag color="gold">收藏</Tag>}
                      {item.pinned && <Tag color="purple">置顶</Tag>}
                    </div>
                  </div>
                  <div
                    style={{
                      padding: '10px',
                      backgroundColor: '#f9f9f9',
                      borderRadius: '4px',
                      maxHeight: '120px',
                      overflowY: 'auto'
                    }}
                  >
                    <Typography.Paragraph
                      ellipsis={{ rows: 3, expandable: true, symbol: '展开' }}
                      style={{ marginBottom: 0, whiteSpace: 'pre-wrap' }}
                    >
                      {item.content}
                    </Typography.Paragraph>
                  </div>
                </div>
              </List.Item>
            );
          }}
        />
      </div>
    </Modal>
  );

  // 替换原来的handleNextStep函数，简化为直接跳转
  const handleNextStep = () => {
    handleAnalyzeItems();
  };

  return (
    <div className="home-container">
      {/* 清空剪贴板功能提示区 */}
      <div className="clear-clipboard-banner glass-container" style={{
        padding: '20px 24px',
        marginBottom: '24px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <div>
          <Title level={4} style={{ 
            margin: 0,
            marginBottom: '4px',
            color: isDarkMode ? '#4dabff' : '#1890ff',
            fontWeight: 500
          }}>
            剪贴板历史
          </Title>
          <Text type="secondary" style={{ fontSize: '14px' }}>共 {filteredItemsWithIndex.length} 条记录</Text>
        </div>
        
        <Space>
          <Button
            type="primary"
            icon={<RobotOutlined />}
            onClick={openAIAnalysisModal}
            style={{
              display: 'flex',
              alignItems: 'center'
            }}
          >
            AI分析
          </Button>
          
          <Dropdown
            menu={{
              items: [
                {
                  key: 'all',
                  label: '清空所有',
                  icon: <DeleteFilled />,
                  danger: true,
                  onClick: () => {
                    Modal.confirm({
                      title: '确认清空',
                      content: '确定要清空所有剪贴板历史记录吗？此操作不可恢复。',
                      okText: '确认清空',
                      cancelText: '取消',
                      okButtonProps: { danger: true },
                      onOk: () => handleClearOption(ClearOption.ALL)
                    });
                  }
                },
                {
                  key: 'today',
                  label: '清空今天',
                  icon: <ClearOutlined />,
                  onClick: () => handleClearOption(ClearOption.TODAY)
                },
                {
                  key: 'week',
                  label: '清空本周',
                  icon: <ClearOutlined />,
                  onClick: () => handleClearOption(ClearOption.THIS_WEEK)
                },
                {
                  key: 'pinned',
                  label: '清空固定',
                  icon: <PushpinOutlined />,
                  onClick: () => handleClearOption(ClearOption.PINNED)
                },
                {
                  key: 'favorites',
                  label: '清空收藏',
                  icon: <StarOutlined />,
                  onClick: () => handleClearOption(ClearOption.FAVORITES)
                },
                {
                  key: 'current',
                  label: '清空当前列表',
                  icon: <DeleteOutlined />,
                  onClick: () => {
                    // 清空当前筛选后的列表
                    if (filteredItems.length > 0) {
                      Modal.confirm({
                        title: '确认清空',
                        content: `确定要清空当前筛选的 ${filteredItems.length} 条记录吗？`,
                        okText: '确认清空',
                        cancelText: '取消',
                        okButtonProps: { danger: true },
                        onOk: () => {
                          filteredItems.forEach(item => {
                            removeItem(item.id);
                          });
                          message.success('已清空当前列表');
                        }
                      });
                    } else {
                      message.info('当前没有可清空的记录');
                    }
                  }
                }
              ]
            }}
            placement="bottomRight"
            trigger={['click']}
            overlayStyle={{ zIndex: 1050 }}
          >
            <Button 
              danger
              icon={<ClearOutlined />}
              style={{ 
                display: 'flex', 
                alignItems: 'center',
                borderRadius: '8px',
                background: isDarkMode ? 
                  'rgba(255, 77, 79, 0.8)' : 
                  '#ff4d4f',
                border: 'none',
                boxShadow: '0 4px 12px rgba(245, 34, 45, 0.3)',
                padding: '0 16px',
                height: '36px',
                color: '#fff'
              }}
            >
              清空
              <DownOutlined style={{ marginLeft: '6px' }} />
            </Button>
          </Dropdown>
        </Space>
      </div>
      
      {/* 工具栏 */}
      <div className="clipboard-toolbar glass-effect" style={{ 
        marginBottom: 24, 
        padding: '16px 20px',
        borderRadius: '16px'
      }}>
        <Row gutter={[16, 16]} align="middle">
          <Col xs={24} md={16} lg={17} xl={18}>
            <Space>
              <Search
                placeholder="搜索剪贴板内容..."
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                allowClear
                style={{ 
                  width: '300px',
                  borderRadius: '12px',
                  overflow: 'hidden'
                }}
              />
              
              <Segmented
                options={[
                  {
                    value: 'list',
                    icon: <BarsOutlined />,
                  },
                  {
                    value: 'grid',
                    icon: <AppstoreOutlined />,
                  },
                ]}
                value={viewMode}
                onChange={(value) => setViewMode(value as 'list' | 'grid')}
                style={{
                  background: isDarkMode ? 'rgba(0, 0, 0, 0.2)' : 'rgba(255, 255, 255, 0.5)',
                  padding: '2px',
                  borderRadius: '12px',
                  border: isDarkMode ? '1px solid rgba(255, 255, 255, 0.1)' : '1px solid rgba(0, 0, 0, 0.05)'
                }}
              />
            </Space>
          </Col>
          <Col xs={24} md={8} lg={7} xl={6}>
            <Space wrap style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Tooltip title="刷新">
                <Button 
                  type="default" 
                  icon={<SyncOutlined spin={isLoading} />} 
                  onClick={handleManualRefresh}
                  loading={isLoading}
                  disabled={isLoading}
                  style={{
                    borderRadius: '8px',
                    background: isDarkMode ? 'rgba(24, 144, 255, 0.1)' : 'rgba(24, 144, 255, 0.05)',
                    border: '1px solid rgba(24, 144, 255, 0.2)',
                    color: '#1890ff',
                    transition: 'all 0.3s ease',
                    boxShadow: isDarkMode ? '0 2px 6px rgba(0, 0, 0, 0.2)' : '0 2px 6px rgba(0, 0, 0, 0.05)'
                  }}
                >
                  {isLoading ? '刷新中' : '刷新'}
                </Button>
              </Tooltip>
              
              <Badge dot={showFavoritesOnly || showPinnedOnly || !!selectedCategory}>
                <Button 
                  icon={<FilterOutlined />} 
                  onClick={() => setShowFilterDrawer(true)}
                  style={{
                    borderRadius: '8px',
                    background: showFavoritesOnly || showPinnedOnly || !!selectedCategory 
                      ? (isDarkMode ? 'rgba(82, 196, 26, 0.15)' : 'rgba(82, 196, 26, 0.1)')
                      : (isDarkMode ? 'rgba(0, 0, 0, 0.2)' : 'rgba(0, 0, 0, 0.04)'),
                    border: (showFavoritesOnly || showPinnedOnly || !!selectedCategory)
                      ? '1px solid rgba(82, 196, 26, 0.3)'
                      : isDarkMode ? '1px solid rgba(255, 255, 255, 0.15)' : '1px solid rgba(0, 0, 0, 0.1)',
                    color: (showFavoritesOnly || showPinnedOnly || !!selectedCategory) 
                      ? '#52c41a' 
                      : isDarkMode ? 'rgba(255, 255, 255, 0.85)' : 'rgba(0, 0, 0, 0.65)',
                    transition: 'all 0.3s ease',
                    boxShadow: isDarkMode ? '0 2px 6px rgba(0, 0, 0, 0.2)' : '0 2px 6px rgba(0, 0, 0, 0.05)'
                  }}
                >
                  筛选
                </Button>
              </Badge>
            </Space>
          </Col>
        </Row>
      </div>
      
      {/* 剪贴板内容列表 */}
      <div className="clipboard-content-container glass-container" style={{ 
        padding: '20px', 
        minHeight: '400px',
      }}>
        <Spin spinning={isLoading} tip={isLoading ? "正在加载剪贴板数据..." : ""}>
          {filteredItemsWithIndex.length > 0 ? (
            viewMode === 'list' ? (
              <List
                className="clipboard-list"
                dataSource={filteredItemsWithIndex}
                renderItem={(item, index) => (
                  <List.Item className="clipboard-list-item" key={item.id}>
                    <div className={`list-item-container ${isDarkMode ? 'dark-theme' : ''}`} style={{
                      borderLeft: `4px solid ${getCategoryColor(item.item.category || 'text')}`,
                      borderRadius: '12px',
                      overflow: 'hidden',
                      boxShadow: isDarkMode 
                        ? '0 4px 16px rgba(0, 0, 0, 0.15)' 
                        : '0 4px 16px rgba(0, 0, 0, 0.06)',
                      transition: 'all 0.3s ease',
                      background: isDarkMode 
                        ? `linear-gradient(135deg, rgba(18, 18, 18, 0.9), rgba(30, 30, 30, 0.95))` 
                        : `linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 248, 248, 0.98))`,
                    }}>
                      <div className="clipboard-card-content" style={{ display: 'flex', alignItems: 'flex-start', position: 'relative' }}>
                        {/* 修改序号样式，取消绝对定位，改为内联元素 */}
                        <div className="clipboard-index" style={{ 
                          fontWeight: 'bold',
                          color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.4)',
                          fontSize: '16px',
                          marginRight: '8px'
                        }}>
                          #{index + 1}
                        </div>
                        
                        <div 
                          className={`clipboard-content ${isExpanded(item.item.id) ? '' : 'content-ellipsis'}`}
                          style={{ cursor: 'pointer', flex: 1 }}
                          onClick={() => showItemDetails(item.item)}
                          onDoubleClick={() => showItemDetails(item.item)}
                        >
                          {item.item.content}
                        </div>
                        {!isExpanded(item.item.id) && item.item.content.length > 150 && (
                          <Button 
                            type="link" 
                            size="small" 
                            onClick={(e) => toggleExpand(item.item.id, e)}
                            icon={<DownOutlined />}
                          >
                            展开
                          </Button>
                        )}
                        {isExpanded(item.item.id) && (
                          <Button 
                            type="link" 
                            size="small" 
                            onClick={(e) => toggleExpand(item.item.id, e)}
                            icon={<UpOutlined />}
                          >
                            收起
                          </Button>
                        )}
                        
                        <div className="clipboard-footer">
                          <div className="clipboard-info">
                            <Space wrap>
                              {item.item.category && (
                                <span className="clipboard-category" style={{
                                  display: 'inline-block',
                                  padding: '2px 8px',
                                  fontSize: '12px',
                                  borderRadius: '12px',
                                  background: isDarkMode 
                                    ? `rgba(${getCategoryColor(item.item.category).replace(/[^\d,]/g, '')}, 0.15)` 
                                    : `rgba(${getCategoryColor(item.item.category).replace(/[^\d,]/g, '')}, 0.08)`,
                                  color: getCategoryColor(item.item.category),
                                  border: `1px solid ${getCategoryColor(item.item.category).replace('rgb', 'rgba').replace(')', ', 0.3)')}`,
                                  marginRight: '8px'
                                }}>
                                  {getCategoryLabel(item.item.category)}
                                </span>
                              )}
                              <span className="clipboard-timestamp" style={{ 
                                fontSize: '12px', 
                                color: isDarkMode ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.45)',
                                display: 'flex',
                                alignItems: 'center'
                              }}>
                                <ClockCircleOutlined style={{ marginRight: 4 }} />
                                {format(new Date(item.item.timestamp), 'MM-dd HH:mm')}
                              </span>
                            </Space>
                          </div>
                          <div className="clipboard-actions">
                            <Tooltip title="AI分析">
                              <Button 
                                type="primary" 
                                size="small" 
                                icon={<RobotOutlined />} 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleAnalyzeItem(item.item);
                                }} 
                                style={{ marginRight: '5px' }}
                              >
                                AI分析
                              </Button>
                            </Tooltip>
                            <Tooltip title="复制到剪贴板">
                              <Button type="text" size="small" icon={<CopyOutlined />} onClick={(e) => {
                                e.stopPropagation();
                                copyToClipboard(item.item.id);
                              }} />
                            </Tooltip>
                            <Tooltip title={item.item.favorite ? "取消收藏" : "收藏"}>
                              <Button 
                                type="text" 
                                size="small" 
                                icon={<StarOutlined />} 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  favoriteItem(item.item.id);
                                }}
                                style={{ color: item.item.favorite ? '#faad14' : undefined }} 
                              />
                            </Tooltip>
                            <Tooltip title={item.item.pinned ? "取消固定" : "固定"}>
                              <Button 
                                type="text" 
                                size="small" 
                                icon={<PushpinOutlined />} 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  pinItem(item.item.id);
                                }}
                                style={{ color: item.item.pinned ? '#1890ff' : undefined }} 
                              />
                            </Tooltip>
                            <Dropdown 
                              menu={{ 
                                items: [
                                  {
                                    key: 'translate',
                                    label: '翻译',
                                    icon: <TranslationOutlined />,
                                    onClick: () => showItemDetails(item.item)
                                  },
                                  {
                                    key: 'edit',
                                    label: '编辑',
                                    icon: <EditOutlined />,
                                    onClick: () => showItemDetails(item.item)
                                  },
                                  {
                                    key: 'details',
                                    label: '详情',
                                    icon: <InfoCircleOutlined />,
                                    onClick: () => showItemDetails(item.item)
                                  },
                                  {
                                    type: 'divider'
                                  },
                                  {
                                    key: 'delete',
                                    label: '删除',
                                    icon: <DeleteOutlined />,
                                    danger: true,
                                    onClick: () => {
                                      removeItem(item.item.id);
                                    }
                                  }
                                ]
                              }} 
                              placement="bottomRight"
                            >
                              <Button type="text" size="small" icon={<MoreOutlined />} />
                            </Dropdown>
                          </div>
                        </div>
                      </div>
                    </div>
                  </List.Item>
                )}
              />
            ) : (
              <Row gutter={[16, 16]} className="clipboard-grid">
                {filteredItemsWithIndex.map(({ item, index }) => (
                  <Col xs={24} sm={12} md={8} lg={6} xl={6} xxl={4} key={item.id} className="grid-col-sm grid-col-md grid-col-lg">
                    <ClipboardCard 
                      item={item}
                      isExpanded={isExpanded(item.id)}
                      toggleExpand={toggleExpand}
                      onDetails={showItemDetails}
                      onCopy={copyToClipboard}
                      onFavorite={favoriteItem}
                      onPin={pinItem}
                      onDelete={removeItem}
                      onMore={showItemDetails}
                      onAnalyze={handleAnalyzeItem}
                      viewMode="grid"
                      isDarkMode={isDarkMode}
                    />
                  </Col>
                ))}
              </Row>
            )
          ) : (
            <div style={{ padding: '40px 0' }}>
              <Empty 
                description={
                  <Text className="neon-text">
                    {isLoading 
                      ? "正在加载剪贴板数据..." 
                      : "暂无剪贴板记录"
                    }
                  </Text>
                } 
                image={Empty.PRESENTED_IMAGE_SIMPLE}
              />
            </div>
          )}
        </Spin>
      </div>
      
      {/* 筛选抽屉 */}
      <Drawer
        title="筛选选项"
        placement="right"
        onClose={() => setShowFilterDrawer(false)}
        open={showFilterDrawer}
        width={300}
        className="glass-drawer"
      >
        <Space direction="vertical" style={{ width: '100%' }} size="large">
          <div>
            <Title level={5}>收藏与固定</Title>
            <Space direction="vertical" style={{ width: '100%' }}>
              <Button 
                type={showFavoritesOnly ? "primary" : "default"}
                icon={<StarOutlined />} 
                onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                style={{ width: '100%' }}
              >
                {showFavoritesOnly ? "取消只看收藏" : "只看收藏内容"}
              </Button>
              
              <Button 
                type={showPinnedOnly ? "primary" : "default"}
                icon={<PushpinOutlined />} 
                onClick={() => setShowPinnedOnly(!showPinnedOnly)}
                style={{ width: '100%' }}
              >
                {showPinnedOnly ? "取消只看固定" : "只看固定内容"}
              </Button>
            </Space>
          </div>
          
          <div>
            <Title level={5}>时间范围</Title>
            <Radio.Group 
              value={filterDateRange.type} 
              onChange={(e) => handleFilterTimeRangeSelect(e.target.value)}
              buttonStyle="solid"
              style={{ marginBottom: 16, display: 'flex', flexWrap: 'wrap', gap: '8px' }}
            >
              <Radio.Button value="today">今天</Radio.Button>
              <Radio.Button value="week">本周</Radio.Button>
              <Radio.Button value="month">本月</Radio.Button>
              <Radio.Button value="custom">自定义</Radio.Button>
              <Radio.Button value={null}>全部</Radio.Button>
            </Radio.Group>
            
            {filterDateRange.type === 'custom' && (
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <DatePicker
                  placeholder="开始日期"
                  locale={locale}
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  value={filterDateRange.startDate ? dayjs(filterDateRange.startDate) : null}
                  onChange={(date) => {
                    setFilterDateRange(prev => ({
                      ...prev,
                      startDate: date ? date.toDate() : null
                    }));
                  }}
                  style={{ width: '100%' }}
                />
                <DatePicker
                  placeholder="结束日期"
                  locale={locale}
                  showTime={{ format: 'HH:mm:ss' }}
                  format="YYYY-MM-DD HH:mm:ss"
                  value={filterDateRange.endDate ? dayjs(filterDateRange.endDate) : null}
                  onChange={(date) => {
                    setFilterDateRange(prev => ({
                      ...prev,
                      endDate: date ? date.toDate() : null
                    }));
                  }}
                  style={{ width: '100%' }}
                />
                <Button 
                  type="primary"
                  onClick={() => {
                    if (!filterDateRange.startDate || !filterDateRange.endDate) {
                      message.warning('请选择开始和结束日期');
                      return;
                    }
                  }}
                  style={{ marginTop: '8px' }}
                >
                  应用时间筛选
                </Button>
              </div>
            )}
          </div>
          
          <div>
            <Title level={5}>按分类筛选</Title>
            <Radio.Group 
              optionType="button" 
              buttonStyle="solid"
              value={selectedCategory || 'all'}
              onChange={(e) => setSelectedCategory(e.target.value === 'all' ? null : e.target.value)}
              style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}
            >
              {PREDEFINED_CATEGORIES.map(category => (
                <Radio.Button 
                  value={category.value} 
                  key={category.value}
                  style={{ marginBottom: 8 }}
                >
                  {category.label}
                </Radio.Button>
              ))}
            </Radio.Group>
          </div>
        </Space>
      </Drawer>
      
      {/* 详情抽屉 */}
      <Drawer
        title="内容详情"
        placement="right"
        onClose={() => {
          setShowDetailsDrawer(false);
          setEditMode(false);
        }}
        open={showDetailsDrawer}
        width={500}
        className="details-drawer glass-drawer"
        extra={
          currentItem && (
            <Space>
              <Tooltip title="复制">
                <Button icon={<CopyOutlined />} onClick={() => {
                  if (currentItem) copyToClipboard(currentItem.id);
                  message.success('已复制到剪贴板');
                }} />
              </Tooltip>
              <Tooltip title="删除">
                <Button danger icon={<DeleteOutlined />} onClick={() => {
                  if (currentItem) {
                    removeItem(currentItem.id);
                    setShowDetailsDrawer(false);
                  }
                }} />
              </Tooltip>
            </Space>
          )
        }
      >
        {currentItem ? (
          <Space direction="vertical" style={{ width: '100%' }} size="large">
            <div>
              <Title level={5}>内容</Title>
              <div className="content-box glass-effect" style={{ padding: 16, maxHeight: '300px', overflow: 'auto' }}>
                {editMode ? (
                  <div>
                    <Input.TextArea 
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      autoSize={{ minRows: 3, maxRows: 12 }}
                      style={{ width: '100%', marginBottom: '10px' }}
                    />
                    <Space>
                      <Button 
                        type="primary"
                        onClick={() => {
                          if (editContent !== currentItem.content && currentItem) {
                            // 使用新的editItem方法直接编辑当前项
                            editItem(currentItem.id, editContent)
                              .then(() => {
                                message.success('内容已更新');
                                setEditMode(false);
                                setShowDetailsDrawer(false);
                                // 延迟后重新获取数据，确保UI更新
                                setTimeout(() => {
                                  fetchItems();
                                }, 300);
                              })
                              .catch(err => {
                                message.error('更新失败: ' + err);
                              });
                          } else {
                            setEditMode(false);
                          }
                        }}
                      >
                        保存
                      </Button>
                      <Button 
                        onClick={() => {
                          if (currentItem) {
                            setEditContent(currentItem.content);
                          }
                          setEditMode(false);
                        }}
                      >
                        取消
                      </Button>
                    </Space>
                  </div>
                ) : (
                  <>
                    <Paragraph copyable style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{currentItem.content}</Paragraph>
                    <Button 
                      icon={<EditOutlined />} 
                      style={{ marginTop: 16 }}
                      onClick={() => {
                        setEditContent(currentItem.content);
                        setEditMode(true);
                      }}
                    >
                      编辑内容
                    </Button>
                  </>
                )}
              </div>
            </div>
            
            <div>
              <Title level={5}>时间</Title>
              <Text>{format(new Date(currentItem.timestamp), 'yyyy-MM-dd HH:mm:ss')}</Text>
            </div>
            
            <div>
              <Title level={5}>分类</Title>
              <Radio.Group 
                value={currentItem.category || 'text'} 
                onChange={(e) => handleCategoryChange(currentItem.id, e.target.value)}
                optionType="button"
                buttonStyle="solid"
                style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}
              >
                {PREDEFINED_CATEGORIES.filter(c => c.value !== 'all').map(category => (
                  <Radio.Button 
                    value={category.value}
                    key={category.value}
                  >
                    {category.label}
                  </Radio.Button>
                ))}
              </Radio.Group>
            </div>
            
            <div>
              <Title level={5}>属性</Title>
              <Space wrap>
                <Button 
                  type={currentItem.favorite ? "primary" : "default"}
                  icon={<StarOutlined />}
                  onClick={() => favoriteItem(currentItem.id)}
                >
                  {currentItem.favorite ? "取消收藏" : "收藏"}
                </Button>
                
                <Button 
                  type={currentItem.pinned ? "primary" : "default"}
                  icon={<PushpinOutlined />}
                  onClick={() => pinItem(currentItem.id)}
                >
                  {currentItem.pinned ? "取消固定" : "固定"}
                </Button>
                
                <Button 
                  icon={<RobotOutlined />}
                  onClick={() => {
                    setShowDetailsDrawer(false);
                    setTimeout(() => {
                      handleAnalyzeItem(currentItem);
                    }, 100);
                  }}
                >
                  AI分析
                </Button>
              </Space>
            </div>
            
            {currentItem.translation && (
              <div>
                <Title level={5}>翻译</Title>
                <div className="translation-box glass-effect" style={{ padding: 16 }}>
                  <Paragraph style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{currentItem.translation}</Paragraph>
                </div>
              </div>
            )}
            
            {currentItem.summary && (
              <div>
                <Title level={5}>总结</Title>
                <div className="summary-box glass-effect" style={{ padding: 16 }}>
                  <Paragraph style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{currentItem.summary}</Paragraph>
                </div>
              </div>
            )}
          </Space>
        ) : (
          <Empty description="未找到详情数据" />
        )}
      </Drawer>
      
      {/* AI分析模态框 */}
      {renderAIAnalysisModal()}
    </div>
  );
};

export default Home; 